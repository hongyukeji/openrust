# 限流与请求节流骨架

以 Laravel Framework v13.40.0 为准。固定 Goravel v1.18.0 用于参考按名称注册请求策略、缓存存储与中间件的分工。窗口、默认键、错误和响应头以 Laravel 为准。Goravel 使用令牌桶，其窗口与默认键不作为本框架契约。 [固定 Laravel RateLimiter](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Cache/RateLimiter.php) · [固定 Goravel Throttle](https://github.com/goravel/framework/blob/a554ced468cada50a269780692a0491e5f9e3a11/http/middleware/throttle.go)

## openrust-v0.x 复用核对

已只读核对 `openrust-v0.x` 的 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。以下路径相对旧版 `vendor/openrust/framework/`。本轮仅核对旧代码与用例。

| 路径 | 实现阶段可提取部分 |
| --- | --- |
| `src/core/rate_limit.rs` | 提取首次命中启动窗口、读取不计数、清除后可重试、存储故障传播的用例。旧版独立 `RateLimitStore` 由当前 Cache Repository 和 Redis 连接契约承接。 |
| `src/http/rate_limit.rs`、`tests/http/router.rs` | 提取请求作用域身份、自定义键隔离、可信客户端 IP 和 429 的实际 HTTP 回归。默认键与响应头按固定 Laravel 重写。 |
| `src/database/rate_limit/{tests,real_server_tests}.rs` | 提取首次到期、并发计数和跨进程校验思路，分别接到 Cache 的数据库驱动与 Redis。旧专用计数表和配置不迁入。 |
| `src/auth/fortify/throttle.rs` | 提取命名与失败计数的接线、登录后清除的思路。Fortify 策略复用统一限流器，旧扩展专属注册器和键格式不作为兼容目标。 |

## 目录与公开接口

以下文件相对 `vendor/openrust/framework/src/`。当前声明公开类型和回调签名，方法和中间件行为在实现阶段填充。

| 职责 | 公开路径 | 文件 |
| --- | --- | --- |
| 缓存限流与应用便捷入口 | `openrust::cache::RateLimiter`、`openrust::support::facades::RateLimiter` | `cache/rate_limiter.rs`、`support/facades.rs` |
| 策略与命名回调 | `openrust::cache::rate_limiting::{Limit, Unlimited, Limiter, LimiterResponse, Attempt, AfterCallback, ResponseCallback}` | `cache/rate_limiting/` |
| 路由节流 | `openrust::routing::middleware::{ThrottleRequests, ThrottleRequestsWithRedis}` | `routing/middleware/` |
| Redis 时间窗口 | `openrust::redis::limiters::DurationLimiter` | `redis/limiters/` |

- `RateLimiter::r#for(name, callback)` 按应用注册命名策略，`limiter(name)` 查找。Rust 的 `r#for` 保留上游的 `for` 拼写。策略接收当前请求，可返回一个或多个 `Limit`、`Unlimited` 或直接返回 HTTP 响应。多个规则保留声明顺序，同名重复键按 `fallbackKey` 对照上游区分。
- `Limit` 预定 `perSecond`、`perMinute`、`perMinutes`、`perHour`、`perDay` 和 `none`，并以 `by`、`after`、`response` 配置键、响应计数条件和拒绝回调。`after` 接收已生成的响应，返回是否计入本次尝试。
- `RateLimiter` 的计数接口为 `attempt`、`tooManyAttempts`、`hit`、`increment`、`decrement`、`attempts`、`resetAttempts`、`remaining`、`retriesLeft`、`clear`、`availableIn`。计数操作沿用 Cache 的异步 `CacheResult`；`attempt` 用 `Attempt<T>` 区分达到上限而跳过与回调实际执行后的返回值，获准时先执行回调，再计数。默认窗口 60 秒，`availableIn` 返回可重试前的剩余秒数。 [固定 Limit](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Cache/RateLimiting/Limit.php)

接口参数以 `&str` 表示键和策略名，以 `Duration` 表示窗口。计数和增减量沿用 Repository 的 `i64`；剩余额度及等待秒数归零饱和。两种节流中间件复用既有 `contracts::http::Middleware::handle(&mut Request, Next)`，返回 `HttpFuture<Result<Response, HttpError>>`，由路由装配传入已解析的限流规则。

## 缓存、Redis 与 HTTP 429

- CacheServiceProvider 在当前应用绑定单例 RateLimiter。通过 [config/cache.rs](../../../config/cache.rs) 的 `cache.limiter` 选择专用存储，未指定时跟随默认 Cache 驱动。使用既有 Repository 的原子新增、计数与删除操作。首次命中启动窗口，后续命中保留计时器；过期后重开，`clear` 同时删除计数和计时器。存储错误通过既有 HTTP 错误链呈现，与超限响应区分。
- 路由使用 `throttle:<name>` 或 `throttle:<maxAttempts>,<decayMinutes>[,<prefix>]`，`ThrottleRequests::using` 和 `with` 预留等价的编译期入口。`Middleware::throttleApi` 显式给 API 组接入节流。按上游，数字规则优先取已认证用户 ID，访客使用路由域名与可信客户端 IP。命名规则按名称和 `Limit::by` 键隔离，保留上游默认键哈希及显式开关。限流器不存在是配置错误。
- 选择 Redis Cache 驱动时，通用 RateLimiter 仍经 Cache Repository。`Middleware::throttleWithRedis` 切换 HTTP 的 `throttle` 别名，由 `ThrottleRequestsWithRedis` 经 RedisManager 的默认连接使用 `DurationLimiter`。按固定 Lua 契约单次原子更新每个窗口的计数、剩余量和重置时间。多规则的检查、计入和回程顺序分别对照普通及 Redis 中间件。分布式后端故障走错误链，保留相同的共享配额语义。
- 默认超限返回 429，由既有 HTTP 异常渲染路径协商 HTML 或 JSON。`Retry-After` 是秒数，`X-RateLimit-Reset` 是 Unix 时间戳；获准和拒绝的响应按上游附带 `X-RateLimit-Limit`、`X-RateLimit-Remaining`。多规则按上游保留更低的剩余额度头。自定义拒绝回调收到请求及对应响应头，并按固定实现使用其返回的响应。 [固定 ThrottleRequests](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Routing/Middleware/ThrottleRequests.php) · [固定 Redis 中间件](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Routing/Middleware/ThrottleRequestsWithRedis.php) · [缓存骨架](cache-redis.md)

## 认证流程接线

| 流程 | 目标契约 |
| --- | --- |
| 登录 | SessionGuard 负责凭据认证。Fortify v1.41.0 的默认登录管线通过同一 RateLimiter 按规范化用户名和可信 IP 计失败次数，每 60 秒 5 次，成功后清除。显式设置 `fortify.limiters.login` 时走命名路由限流，避免两条管线重复计数。保留默认认证锁定响应与通用 HTTP 429 的区别。 |
| 密码重置 | Broker 自身的 `auth.passwords.<name>.throttle` 由 TokenRepository 约束同一用户的新令牌签发，默认 60 秒，命中时返回 `passwords.throttled`。应用可在发送或提交重置的路由上另挂命名限流器，独立于令牌有效期和 Broker 的返回状态。 |
| 邮箱验证重发 | 沿用应用命名路由 `verification.send`，先 `auth` 再 `throttle:6,1`，每分钟最多 6 次。使用请求内身份，超限时在通知发出前返回 429。Fortify 可用 `fortify.limiters.verification` 显式覆盖。 |

[固定 Fortify LoginRateLimiter](https://github.com/laravel/fortify/blob/v1.41.0/src/LoginRateLimiter.php) · [固定 Fortify 路由](https://github.com/laravel/fortify/blob/v1.41.0/routes/routes.php) · [密码重置与邮箱验证骨架](password-reset-email-verification.md) · [认证骨架](auth.md)

## 填充与验收顺序

1. 先接 Cache Repository 和命名注册，验证窗口、过期、清除、回调、多规则和存储失败。
2. 接普通及 Redis 路由节流，分别对照固定测试。用真实 HTTP 验证获准与拒绝、429、头部、自定义响应、按响应计数，以及 Redis 并发和跨进程。
3. 接登录、重置令牌和邮箱重发，核对命名覆盖、认证身份、计数隔离及无多发通知。功能通过后再补三语正文。 [固定 Laravel 限流测试](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/tests/Integration/Http/ThrottleRequestsTest.php)
