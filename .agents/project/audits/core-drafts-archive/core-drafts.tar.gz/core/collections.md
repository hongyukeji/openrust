# 集合与惰性集合骨架

以固定 Laravel Framework v13.40.0 的 `Illuminate\Support\Collection`、`LazyCollection` 和 `Enumerable` 为准。Goravel v1.18.0 参考泛型集合与惰性迭代器的拆分。Goravel 用列表位置标识条目，OpenRust 沿用 Laravel 的整数键、字符串键和迭代顺序。 [固定 Laravel Collections 源码](https://github.com/laravel/framework/tree/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Collections) · [固定 Goravel Collect 源码](https://github.com/goravel/framework/tree/a554ced468cada50a269780692a0491e5f9e3a11/support/collect)

## openrust-v0.x 复用核对

已只读核对 `openrust-v0.x` 提交 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。以下路径相对旧版 `vendor/openrust/framework/`。

| 旧版路径 | 实现阶段可提取部分 |
| --- | --- |
| `src/support/collection.rs` | 提取整数与字符串键、规范数字字符串归一化、保序存储、覆盖位置、稀疏键和 `values` 重排的实现。复用数组／对象 JSON 形状及非有限数字拒绝用例。源码内的测试迁入独立测试目录。 |
| `src/database/eloquent/{collection_cast,encrypted_collection_cast,enum_collection_cast}.rs`、`tests/unit/database/eloquent/encrypted_collection_cast.rs` | 复用从数据库属性转为集合及保留键的回归。属性 cast 的集合与查询返回的模型集合分别接线。 |

旧版树中未发现可直接迁入的 `LazyCollection` 或 `Enumerable`。惰性行为以固定 Laravel 的 `SupportLazyCollectionIsLazyTest` 和 Goravel 迭代器实现作对照。 [Laravel 惰性测试](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/tests/Support/SupportLazyCollectionIsLazyTest.php)

## 目录与公开接口

| 职责 | 公开导入 | 框架文件 |
| --- | --- | --- |
| 普通集合与键 | `openrust::support::{Collection, ArrayKey, CollectionError, CollectionResult}` | `src/support/collection.rs` |
| 惰性集合与源工厂 | `openrust::support::{LazyCollection, LazySource}` | `src/support/lazy_collection.rs` |
| 通用枚举能力 | `openrust::support::Enumerable` | `src/support/enumerable.rs` |
| 模型集合 | `openrust::database::eloquent::Collection<M>` | `src/database/eloquent/collection.rs` |

- `Enumerable` 声明 `all`、`collect`、`map`、`filter`、`values` 和 `take`。类型变换用关联类型保留普通或惰性集合类别。Rust 终止操作消耗集合，调用方可通过迭代借用普通集合，或用惰性源工厂重新遍历。可失败的数据源错误在遍历时传播。
- 普通集合保留插入顺序。 `map`、`filter` 和正向 `take` 保留键，`values` 才从零重新索引。 `all` 交付原始键值条目，`collect` 将惰性结果物化为普通集合。序列化按上游区分连续整数键和关联键，分别输出 JSON 数组或对象。 `pluck`、`keys`、`chunk` 和 `mapWithKeys` 在实现阶段按固定用例补齐。
- 惰性集合接收能重新创建迭代器的源工厂，`map`、`filter`、`values` 和正向 `take` 在消费时求值，构造及串接时保持无读取。负向 `take` 需要遍历有限源以保留尾部。 `remember` 只缓存已经遍历的条目，供后续迭代复用。同步迭代器与 Eloquent 的异步数据库游标各自保留边界，后续用异步流适配验证按需读取和取消，避免预先加载整表。 [固定 LazyCollection](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Collections/LazyCollection.php)

## Eloquent、分页和 API Resources 接线

- **Eloquent Collection。** 保留已声明的模型集合路径。后续组合普通 `Collection<M>` 并保留模型键、批量关系加载及模型集合方法。 `toBase` 切换到普通集合。PHP 可在运行时判断 `map` 的输出是否仍为模型，Rust 由类型明确模型操作与投影到普通集合的边界。 [固定 Eloquent Collection](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Database/Eloquent/Collection.php) · [Eloquent 骨架](eloquent.md)
- **分页器。** 通过 `getCollection`、`setCollection` 和 `through` 接入当页数据。变换只作用于已取得的条目，保留总数、游标及导航链接。分页器条目读取沿用已声明的契约，键语义由集合转换接线验证。
- **API Resources。** `ResourceCollection` 在响应阶段转换条目，并由包装策略决定保留键还是重排。显式保留关联键时输出 JSON 对象。资源变换与分页信息分别构建，`data` 转换不改变原分页器提供的 `links` 和 `meta`。无限惰性源须先限定输出范围再物化。 [分页与 API Resources 骨架](pagination-api-resources.md)

## 填充与验收顺序

1. 提取旧版保序集合，按固定测试覆盖键归一化、过滤、映射、重排和序列化。
2. 实现惰性迭代链，验证源启动次数、短路、重复遍历、错误传播和 `remember`。
3. 接入 Eloquent、分页及资源，验收键保留、模型关系和分页元数据。功能验收后填写三语集合章节。
