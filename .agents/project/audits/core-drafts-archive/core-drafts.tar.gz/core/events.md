# 事件与监听器骨架

以 Laravel 为准、参考 Goravel 实现。已声明公开类型与 trait，并预留对应文件。注册、派发、入队和事务回调的运行逻辑随功能簇实现。核对日期为 2026 年 11 月 10 日。 [固定 Laravel 基线](../plans/laravel-rebuild-baseline.md) · [Laravel Dispatcher](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Events/Dispatcher.php) · [Goravel v1.18.0 事件契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/event/events.go)

## 目录与公开导入

框架源码位于 `vendor/openrust/framework/src/`。下表导入均以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 注册和派发 | `events::{Dispatcher, EventServiceProvider, ListenerRegistry}`、`contracts::events::Dispatcher` | `events/`、`contracts/events/dispatcher.rs` |
| 应用事件、监听器和订阅者 | `contracts::events::{Event, Listener, Subscriber}` | `contracts/events/` |
| 派发上下文、模式与返回值 | `events::{EventContext, Delivery, DispatchResult, ListenerResponse, EventFuture, EventResult, EventError}` | `events/mod.rs` |
| 应用注册与发现 | `foundation::support::providers::EventServiceProvider`、`foundation::events::DiscoverEvents` | `foundation/support/providers/`、`foundation/events/` |
| 队列监听 | `events::{CallQueuedListener, QueuedListenerOptions}`、`contracts::queue::{ShouldQueue, ShouldQueueAfterCommit}` | `events/`、`contracts/queue/` |
| 提交后派发与监听 | `contracts::events::{ShouldDispatchAfterCommit, ShouldHandleEventsAfterCommit}`、`database::DatabaseTransactionsManager` | `contracts/events/`、`database/database_transactions_manager.rs` |

应用事件放在 `app/events/`，监听器与订阅者放在 `app/listeners/`。已有 `make:event`、`make:listener` 归 Artisan 生成器契约。`event:list`、`event:cache`、`event:clear` 已预留在 `foundation/console/`。 [Artisan 骨架](artisan.md)

## 注册、发现与同步派发

- 框架 `events::EventServiceProvider` 注册 Dispatcher。应用层 Provider 合并显式映射、Subscriber 和发现清单。Subscriber 通过 `subscribe(&self, registry: &mut ListenerRegistry)` 成组注册，目标注册方法沿用 `listen`。Provider 合并映射时去重，直接调用 `listen` 按登记顺序添加监听器。
- Laravel 默认发现应用的 `app/Listeners`，可配置或关闭。Rust 的 `app/listeners/` 由模块显式纳入，`with_events` 的目标装配入口接收编译期生成的发现清单。清单依据显式声明的事件与处理器关系生成，运行时只消费可执行程序已注册的监听器。缓存只保存可验证的注册清单，清单缺失或与当前构建不符时从已编译的登记重新取得。 [Laravel 应用事件 Provider](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Support/Providers/EventServiceProvider.php) · [Laravel DiscoverEvents](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Events/DiscoverEvents.php)
- `Event::name` 提供稳定事件名。确切名称和通配符使用同一个事件与载荷，按上游匹配顺序派发。框架已固定的公开事件字符串沿用项目命名规范。Rust 用类型或显式适配器登记事件，监听器可按类型读取载荷。
- `Dispatcher::listen` 登记监听器和 `Delivery`，默认应用注册路径使用 `Sync`。`dispatch` 在当前异步调用中顺序等待同步监听器，遇到 `ListenerResponse::Stop` 停止传播，对应 Laravel 的 `false`。`until` 在第一个非空结果时返回。异步签名允许监听器执行 I/O，同步监听仍在调用链中完成。已延后整个事件时 `dispatch` 返回 `Deferred`。 [Laravel Dispatcher 契约](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Contracts/Events/Dispatcher.php)

## 队列监听

`Delivery::Queued` 使用稳定的监听器 ID。注册时关联处理器与事件载荷编解码入口。派发只创建 `CallQueuedListener` 对应的任务载荷，经现有 QueueManager 按连接、队列和延迟选项入队。Worker 在单次任务作用域重新解析监听器并执行。入队结果只表示交给队列。后续重试、退避、超时与终态失败复用队列契约。无法编码或解析的载荷走明确错误路径。

是否入队、唯一监听及监听器失败钩子按上游能力逐项实现。延后入队时使用已拥有的事件载荷或稳定标识，避免在 Worker 中引用原请求借用。 [Laravel CallQueuedListener](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Events/CallQueuedListener.php) · [队列与 Worker 骨架](queue-scheduling.md)

## 事务提交后派发

| 场景 | 目标契约 |
|---|---|
| 事件标记 `ShouldDispatchAfterCommit` | 整个事件延后，包括同步监听与后续入队。Rust 用显式类型登记启用该策略。 |
| 监听器标记 `ShouldHandleEventsAfterCommit` | 只延后该同步监听器，对应 `Delivery::AfterCommit`。其余监听器继续按各自策略执行。 |
| 队列监听标记 `ShouldQueueAfterCommit` | 延后的是入队。显式标记强制开启，未指定时继承队列连接的 `after_commit`。 |

`EventContext` 关联当前操作的事务上下文，数据库层的 `DatabaseTransactionsManager` 统一登记提交回调，供事件和队列复用。无适用事务时立即处理。嵌套提交保留回调到同一连接最外层成功提交，保存点回滚丢弃对应层及其后代，整笔回滚清空该事务的待派发记录。回调持有可跨提交边界的事件数据。提交后监听或入队失败由执行路径报告，已经提交的数据库写入不回滚。 [Laravel 事务回调管理](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/DatabaseTransactionsManager.php) · [数据库事务骨架](database.md)

## Eloquent 接线

- `HasEvents` 使用相同 Dispatcher 的注册、命名和匹配规则，保留 `eloquent.<event>: <模型限定名>`。自定义事件映射先按上游处理。需要借用可变模型及当前连接的 Observer 通过已有 `ModelEventListener<M>` 适配，保留 `Continue`、`Stop`、`Cancel` 语义，避免重复派发。
- `creating`、`updating`、`saving`、`deleting`、`restoring`、`forceDeleting` 保留在写入前，即使 Observer 声明提交后处理也在当前调用中返回决定。适用的后置 Observer 可登记提交回调，延后事件使用自有载荷。批量更新或删除沿用 Eloquent 的实例事件规则。 [Laravel HasEvents](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Eloquent/Concerns/HasEvents.php) · [Eloquent 生命周期骨架](eloquent.md)

## 填充与验收顺序

1. 先接通注册、发现清单和同步派发，核对具名、通配符、Subscriber、顺序与停止传播。
2. 接通队列监听和事务回调，用实际 Worker 验证入队、重试和失败。覆盖无事务、嵌套提交、保存点回滚、外层回滚以及提交后入队失败。
3. 接通 Eloquent Observer，验证写入前取消、普通后置事件和提交后派发。功能验收后填写三语正文。
