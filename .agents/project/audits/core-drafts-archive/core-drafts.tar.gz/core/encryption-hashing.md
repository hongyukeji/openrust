# 加密与哈希骨架

以 Laravel Framework v13.40.0 的公开契约、默认值和数据格式为准。参考固定 Goravel v1.18.0 的 `crypt`、`hash` 服务装配及显式错误。Goravel 的 AES-GCM 载荷和哈希默认驱动与 Laravel 有差异，本框架采用固定 Laravel 的对应契约。 [Laravel 加密](https://laravel.com/docs/13.x/encryption) · [Laravel 哈希](https://laravel.com/docs/13.x/hashing) · [Goravel Crypt](https://github.com/goravel/framework/tree/a554ced468cada50a269780692a0491e5f9e3a11/crypt) · [Goravel Hash](https://github.com/goravel/framework/tree/a554ced468cada50a269780692a0491e5f9e3a11/hash)

## openrust-v0.x 复用核对

已只读核对 `openrust-v0.x` 的 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。以下路径相对旧版 `vendor/openrust/framework/`，测试在实现阶段按新入口移植。

| 旧版实现 | 可复用的实现与验证 |
| --- | --- |
| `src/encryption/application.rs`、`src/encryption/application_payload.rs` | 提取密钥解析、轮换、四种 cipher 的载荷处理和按字节计算长度的 PHP 字符串序列化。复用 `tests/unit/encryption/{application,application_payload}.rs` 和固定 PHP 加密夹具，验证载荷篡改、轮换及认证先于反序列化。 |
| `src/console/command/key_generate.rs` | 核对现有密钥在生产环境下的确认分支、`--show` 与 `--force`。按新 Console Kernel 的环境文件定位和固定版退出行为重新验收。 |
| `src/http/cookie/{crypto,middleware}.rs` | 提取名称绑定、过往密钥和失败处理。复用 `tests/http/fixtures/php85/cookie-wire-golden.json` 与 `tests/http/cookie.rs` 中的受保护路由回归。 |
| `src/hashing/{manager,drivers,parameters}.rs` | 提取驱动解析、密码字节语义及参数校验。复用 `tests/fixtures/hashing_bytes_php85.json`、`src/hashing/bytes_contract_tests.rs` 和 `operation_selection_tests.rs` 中适用于新容器的夹具与并发、循环、重试用例，移到独立测试目录。 |

旧 API、专用密文格式和旧配置键不属于兼容目标。固定 Laravel 的标准载荷与哈希格式是新主线的互操作目标。应用加密和密码哈希属于框架核心，API 正文及实时协议加密另行设计。

## 目录与公开导入

| 职责 | 公开导入 | 框架源码 |
| --- | --- | --- |
| 应用加密、密钥与服务装配 | `openrust::encryption::{Encrypter, EncryptionServiceProvider, Cipher, EncryptException, DecryptException}` | `encryption/` |
| 可注入的加密接口 | `openrust::contracts::encryption::Encrypter` | `contracts/encryption/mod.rs` |
| 命名驱动和密码哈希 | `openrust::hashing::{HashManager, HashingServiceProvider, BcryptHasher, ArgonHasher, Argon2IdHasher}` | `hashing/` |
| 可注入的哈希接口 | `openrust::contracts::hashing::Hasher`、`openrust::hashing::{HashInfo, HashOptions, HashError}` | `contracts/hashing/mod.rs`、`hashing/mod.rs` |
| 便捷入口 | `openrust::support::facades::{Crypt, Hash}` | `support/facades.rs` |
| 密钥命令 | `artisan key:generate` | `foundation/console/key_generate_command.rs` |

模块、类型及 trait 已声明。Manager、Provider、Facade 和命令的执行逻辑随后按下列契约填充。应用配置沿用 [config/app.rs](../../../config/app.rs)、[config/hashing.rs](../../../config/hashing.rs) 和 [.env.example](../../../.env.example)。

## Encrypter、APP_KEY 与轮换

- `EncryptionServiceProvider` 延迟解析应用级单例 `encrypter`，`Crypt` 与契约注入使用同一实例。读取 `app.key`（`APP_KEY`）、`app.cipher` 和 `app.previous_keys`（逗号分隔的 `APP_PREVIOUS_KEYS`）。应用默认 `AES-256-CBC`。支持 AES-128/256 的 CBC 与 GCM，按 cipher 校验密钥字节长度，接受合法的原始值或 `base64:` 值。空密钥在需要 Encrypter 的路径失败，保留空白模板下运行密钥生成命令的入口。
- 新密文使用当前密钥。读取先试当前密钥，再按声明顺序试历史密钥。外层为 Base64 JSON，字段沿用 `iv`、`value`、`mac`、`tag`。CBC 验证 MAC，GCM 验证认证标签。认证完成后再交付或反序列化明文，错误不包含密钥和明文。
- `encryptString` / `decryptString` 传递原始字节。`encrypt` / `decrypt` 的序列化开关对应上游字符串路径，启用时使用按字节计长的 PHP 字符串格式。Rust 无 PHP 动态对象，数组及对象的序列化互操作需另定类型契约和夹具验收。 [固定 Encrypter](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Encryption/Encrypter.php) · [固定应用配置](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/config/app.php)

## key:generate、Cookie 与 Session

- `key:generate [--show] [--force]` 使用系统安全随机源，按 `app.cipher` 生成对应长度的 `base64:` 密钥。`--show` 在命令获准运行后只输出新密钥。默认更新当前选定的环境文件中对应的 `APP_KEY`，成功后同步本次命令的配置。生产环境替换已有密钥前确认，`--force` 跳过该确认。无可替换键、外部环境冲突、用户拒绝等路径按固定命令核对输出、退出状态和文件无副作用，实际写入保留其他配置内容。
- 复用现有 `cookie::middleware::EncryptCookies` 和 `CookieValuePrefix`。默认 Web 中间件在请求入口解密、在响应回程统一加密，按应用配置排除指定名称。前缀使用 Cookie 名与密钥绑定，允许密钥轮换。密文篡改、跨 Cookie 名复制、未知密钥均按无有效 Cookie 处理；保护链故障时禁止明文降级。复用同一 Encrypter 处理 `session.encrypt` 对应的 `EncryptedStore`，会话载荷保护与 HTTP Cookie 保护分别验收。 [固定 KeyGenerateCommand](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Foundation/Console/KeyGenerateCommand.php) · [固定 EncryptCookies](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Cookie/Middleware/EncryptCookies.php) · [Session 骨架](session-cookie-csrf.md)

## HashManager 与认证

- `HashingServiceProvider` 绑定应用级 `hash` 和默认 `hash.driver`，`Hash` 与注入的 `Hasher` 共用配置。Manager 的目标入口为 `driver`、`extend`、`getDefaultDriver`、`info`、`make`、`check`、`needsRehash`、`isHashed` 和 `verifyConfiguration`，按名称解析并复用驱动。
- `HASH_DRIVER` 默认 `bcrypt`，另外支持 `argon`（Argon2i）和 `argon2id`。默认 bcrypt cost 为 12，`HASH_VERIFY` 为 true，`BCRYPT_LIMIT` 未设。Argon 默认内存 65536 KiB、时间成本 4、线程 1。`check` 区分密码不匹配与算法校验错误，`needsRehash` 检查算法和参数。密码输入按字节交给驱动，保留各驱动对长度和无效字节的行为。高成本哈希由有界阻塞任务执行，避免阻塞异步请求线程。
- Database 与 Eloquent 用户 Provider 通过统一 `Hasher` 验证密码。成功验证后，SessionGuard 按 `hashing.rehash_on_login`（默认开启）决定是否触发 `rehashPasswordIfRequired`，仅在需要时持久化新哈希。注册、重置密码和 Eloquent `hashed` cast 使用同一配置，cast 按上游规则检查已哈希输入，避免重复哈希。 [固定哈希配置](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/config/hashing.php) · [固定 HashManager](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Hashing/HashManager.php) · [认证骨架](auth.md) · [Eloquent 骨架](eloquent.md)

## 填充与验收顺序

1. 接入 Encrypter 和 `key:generate`。用固定 PHP 夹具双向验证四种 cipher、原始与序列化字符串、轮换及认证失败，并实测密钥命令的环境文件、确认与输出。
2. 接入 Cookie 和 Session 加密，用真实 HTTP 请求验收轮换、名称绑定、篡改、例外项及 Session 回程。
3. 接入 HashManager、驱动与认证，验证三种驱动的 PHP 互操作、算法检查、rehash、失败登录无写入和成功登录自动升级。功能通过后再填写三语正文。
