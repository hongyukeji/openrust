# 视图与模板渲染骨架

以 Laravel Framework v13.40.0 的视图工厂、命名查找、布局、组件和缓存机制为准。固定 Goravel v1.18.0 用于参考 Provider 绑定、应用视图优先和包视图回退。 [Laravel Views](https://laravel.com/docs/13.x/views) · [Laravel Blade](https://laravel.com/docs/13.x/blade) · [固定 Goravel View](https://github.com/goravel/framework/blob/a554ced468cada50a269780692a0491e5f9e3a11/view/view.go)

## openrust-v0.x 复用核对

已只读核对 `openrust-v0.x` 的 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`，记录以下可提取的实现和用例。实现阶段再通过新接口重跑。

| 旧版路径（相对 `vendor/openrust/framework/`） | 可复用的部分 |
| --- | --- |
| `src/view.rs`、`src/config/view.rs` | 提取模板名校验、文件根约束、包视图覆盖顺序和开发重载的思路。按新的 Factory、Finder、Engine 分工迁入，路径和配置以固定 Laravel 为准。 |
| `tests/http/view.rs` | 提取命名查找、HTML 自动转义、文件更新、符号链接越界、请求错误包隔离、显式数据覆盖和 Session flash 老化的用例。 |
| `src/view/errors.rs`、`src/foundation/exceptions.rs` | 复用验证错误数据的桥接和应用错误视图失败后的安全回退思路，接入现有 ViewErrorBag、Session 中间件与 Handler。 |

旧版使用 MiniJinja。其加载、安全边界和用例可提取，旧模板语法、`Views` API、目录与 Cargo 特性不作为新主线的兼容契约。

## 目录与公开接口

下表的 `src/` 路径相对 `vendor/openrust/framework/`。

| 职责 | 公开路径 | 文件 |
| --- | --- | --- |
| 命名视图、工厂、Provider | `openrust::view::{view, View, Factory, ViewServiceProvider}`、`openrust::support::facades::View` | `src/view/`、`src/support/facades.rs` |
| 视图与工厂契约 | `openrust::contracts::view::{View, Factory, ViewCallback}` | `src/contracts/view/mod.rs` |
| 名称与文件查找 | `openrust::view::{ViewFinder, FileViewFinder}` | `src/view/{view_finder,file_view_finder}.rs` |
| 引擎与编译 | `openrust::contracts::view::Engine`、`openrust::view::engines::{FileEngine, CompilerEngine, EngineResolver}`、`openrust::view::compilers::{Compiler, BladeCompiler}` | `src/view/{engines,compilers}/` |
| 类式组件 | `openrust::view::{Component, ComponentOutput}` | `src/view/component.rs`、[app/view/components/mod.rs](../../../app/view/components/mod.rs) |
| 配置与命令 | `view.paths`、`view.compiled`、`view:cache`、`view:clear` | [config/view.rs](../../../config/view.rs)、`src/foundation/console/{view_cache_command,view_clear_command}.rs` |

工厂声明 `make`、`file`、`exists`、`share`、`creator`、`composer` 和命名空间注册。视图声明 `name`、`with`、`getData` 和 `render`。Finder 声明 `find`、按顺序注册根及命名空间、扩展名和清空查找缓存。Engine 通过 `get(path, data)` 异步返回 HTML。PHP 的动态数据用 `ViewData` 表达，Rust 通过显式输入与输出边界处理模板 I/O。 [固定 Factory](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/View/Factory.php) · [固定 FileViewFinder](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/View/FileViewFinder.php)

## 命名视图与请求数据

- ViewServiceProvider 装配应用级 `view` 工厂、`view.finder`、`view.engine.resolver` 和 `blade.compiler`。默认搜索 `resources/views/`。点分名称映射子目录，`package::view.name` 走包命名空间，应用发布覆盖目录 `resources/views/vendor/<namespace>/` 优先于包原始目录。按有序路径和扩展名查找，文件根约束同时覆盖符号链接。显式 `file` 只接受受信应用提供的路径。
- 视图创建后运行 creator，渲染前运行 composer。显式视图数据覆盖同名共享数据。Session 恢复后，`ShareErrorsFromSession` 将默认与命名错误包接入请求内的视图数据，保持请求隔离，避免污染应用级 `share`。顶层渲染结束后清理布局、组件和嵌套渲染状态。 [Session 骨架](session-cookie-csrf.md)

## 布局、组件与引擎

- 普通 `.html` 走 FileEngine。Blade 模板的目标后缀定为 `.blade.html`，使用独立的 BladeCompiler 与 CompilerEngine，优先匹配完整后缀。Rust 应用没有 PHP 运行时，因此编译为 Rust 引擎可执行的模板产物。按固定 Laravel 测试逐项验证指令、转义与输出，PHP 表达式和 `@php` 的兼容范围须另行定稿。
- 保留上游布局分工。应用模板放 `resources/views/`，布局可放 `resources/views/layouts/`。首批契约覆盖 `@extends`、`@section`、`@yield` 和 `@include`，保留嵌套渲染的数据与继承优先级。
- 匿名组件位于 `resources/views/components/`，类式组件由应用注册在 `app/view/components/`。保留 `<x-…>`、属性袋、默认及命名 slot 和组件数据边界。`{{ … }}` 默认转义，显式原样输出和受信组件内联模板沿用对应的独立入口。 [固定 Blade 编译器](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/View/Compilers/BladeCompiler.php)

## 编译缓存与 HTTP 接线

- `view.compiled` 默认位于 `storage/framework/views/`，由 `VIEW_COMPILED_PATH` 覆盖。Finder 的名称缓存与编译产物分开。Compiler 通过 `getCompiledPath`、`isExpired`、`compile` 管理产物，源文件更新触发重新编译。实现需验证并发编译原子发布和跨引擎产物隔离。`view:cache` 按上游先清理、再编译配置范围内的模板，`view:clear` 只清理编译产物。 [固定 ViewCacheCommand](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Foundation/Console/ViewCacheCommand.php)
- [默认 Web 路由](../../../routes/web.rs) 将 `/` 交给 `WelcomeController::index`。控制器调用 `view("welcome")`，将应用配置中的名称和构建时的 Cargo 包版本传给 [welcome.blade.html](../../../resources/views/welcome.blade.html)。框架通过视图 Factory 解析并渲染该 Blade 模板。 [WelcomeController](../../../app/http/controllers/welcome_controller.rs)
- 异常 Handler 经同一个 Factory 查找 `errors::<status>`，应用覆盖文件放在 `resources/views/errors/<status>.blade.html`。按上游先查状态专页，再查适用的 `errors::4xx`／`errors::5xx`。仍由 Handler 决定 HTML／JSON、状态码和响应头。缺页走框架回退，生产环境渲染失败时报告该错误并回退原响应，调试环境按 Handler 的诊断策略处理。 [异常骨架](logging-exceptions.md) · [固定异常视图查找](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Foundation/Exceptions/Handler.php)

## 填充与验收顺序

1. 接入 Provider、Factory、Finder 和 FileEngine，用普通 `.html` 测试夹具验收命名、命名空间、覆盖、路径隔离和请求数据。
2. 接入编译引擎、布局和组件，对照固定 Blade 用例验证转义、slot、属性、继承和嵌套状态。再验收缓存更新、并发和 Artisan 命令。
3. 接入异常视图与 Session 错误包，实测 HTML／JSON 协商、错误视图失败回退和请求隔离。通过后再填写三语 Views 与 Blade 正文。
