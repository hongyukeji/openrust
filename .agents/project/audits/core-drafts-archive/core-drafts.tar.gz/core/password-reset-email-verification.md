# 密码重置与邮箱验证骨架

公开路径和行为以固定 Laravel Framework v13.40.0 为准。固定 Goravel v1.18.0 参考请求上下文中的 Guard 与 UserProvider 装配，未发现对应的密码代理、邮箱验证或签名链接模块。 [Laravel 密码重置](https://laravel.com/docs/13.x/passwords) · [Laravel 邮箱验证](https://laravel.com/docs/13.x/verification) · [Goravel Auth](https://github.com/goravel/framework/tree/a554ced468cada50a269780692a0491e5f9e3a11/auth)

## openrust-v0.x 复用核对

已只读核对 `openrust-v0.x` 提交 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。以下路径相对旧版 `vendor/openrust/framework/`。

| 旧版实现和测试 | 实现阶段可提取部分 |
| --- | --- |
| `src/routing/url_generator.rs`、`tests/http/router/signed_url.rs`、`tests/fixtures/laravel_signed_url.json` | 提取临时签名、请求原始查询串校验、当前和历史密钥处理，以及固定 PHP 夹具、实际 HTTP 过期与篡改回归。 |
| `src/auth/flows.rs`、`src/auth/flows_operation_tests.rs` | 参考重置完成后的凭据更新和 MySQL、SQLite 回归结构。旧邮箱和重置流程基于一次性验证码。新入口分别采用签名链接和 Laravel 密码重置令牌，旧验证码格式、表结构、路由和额外凭据撤销策略不纳入新默认契约。 |
| `src/hashing/`、`src/mail/`、`tests/server/mail/templates.rs` | 哈希与邮件复用各自功能簇的实现和用例，两个认证流程共用既定服务。 |

## 目录与公开接口

| 职责 | 公开路径 | 目录 |
| --- | --- | --- |
| 命名代理与存储 | `openrust::auth::passwords::{PasswordBroker, PasswordBrokerManager, TokenRepository, DatabaseTokenRepository, CacheTokenRepository, PasswordResetStatus}` | `src/auth/passwords/` |
| 用户与代理契约 | `openrust::contracts::auth::{PasswordBroker, CanResetPassword, MustVerifyEmail}` | `src/contracts/auth/` |
| 密码代理便捷入口 | `openrust::support::facades::Password` | `src/support/facades.rs` |
| 邮箱验证请求和中间件 | `openrust::foundation::auth::EmailVerificationRequest`、`openrust::auth::middleware::EnsureEmailIsVerified` | `src/foundation/auth/`、`src/auth/middleware/` |
| 命名路由和签名验证 | `openrust::routing::UrlGenerator`、`openrust::routing::middleware::ValidateSignature` | `src/routing/` |
| 通知与认证事件 | `openrust::auth::notifications::{ResetPassword, VerifyEmail}`，预留 `auth::events::{Registered, PasswordResetLinkSent, PasswordReset, Verified}` 和 `auth::listeners::SendEmailVerificationNotification` | `src/auth/{notifications,events,listeners}/` |

表中 `src/` 路径位于 `vendor/openrust/framework/`。公开 trait 已声明，Provider、通知、中间件和签名方法在实现阶段填充。应用沿用 [config/auth.rs](../../../config/auth.rs) 和 [默认用户迁移](../../../database/migrations/0001_01_01_000000_create_users_table.rs)。

## PasswordBroker 与重置令牌

- `PasswordBrokerManager::broker` 解析并复用命名代理。默认由 `auth.defaults.passwords`（`AUTH_PASSWORD_BROKER`，默认 `users`）选择，代理在 `auth.passwords.<name>` 下指定 UserProvider、存储和有效期。默认数据库表为 `password_reset_tokens`，以 email 为主键，保存令牌哈希和 `created_at`。默认有效期 60 分钟、重新签发间隔 60 秒。显式 `cache` 驱动使用指定缓存存储及有效期。
- `TokenRepository` 声明 `create`、`exists`、`recentlyCreatedToken`、`delete`、`deleteExpired`。按上游使用安全随机输入和应用密钥生成令牌，`base64:` 应用密钥解码后交给令牌生成器。持久层只存统一 `Hasher` 生成的哈希，新令牌替换同用户旧令牌。失效或已使用令牌应拒绝，数据库清理由 `auth:clear-resets [name]` 接入，缓存依靠 TTL。
- `sendResetLink` 使用配置的 UserProvider 查用户，应用用户须声明 `CanResetPassword`。`reset` 将令牌和新密码与查找凭据分开传递，验证令牌后调用应用回调写入密码，成功后删除令牌。默认应用回调使用 `Hash`、轮换 remember token 并派发 `PasswordReset`，保留应用自定义回调的入口。实现需验证并发请求不能重复使用同一令牌，以及回调失败时的令牌状态。Rust 通过注册的用户模型适配器保留可选能力，解析后确认当前用户支持该能力。
- Broker 保留固定状态 `passwords.sent`、`passwords.reset`、`passwords.user`、`passwords.token`、`passwords.throttled` 的一一映射，并与存储或通知失败区分。按固定源码保留 Timebox 的 200 ms 默认边界和成功重置提前返回。默认通过 `ResetPassword` 邮件生成命名路由 `password.reset`，带令牌和邮箱。自定义通知回调替换默认通知分支；默认分支成功发送后派发 `PasswordResetLinkSent`。重置 URL 由存储令牌校验。 [固定 PasswordBroker](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Auth/Passwords/PasswordBroker.php) · [固定 Auth 配置](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/config/auth.php)

## MustVerifyEmail 与签名链接

- 用户模型可选择实现 `MustVerifyEmail`，由 `hasVerifiedEmail`、`markEmailAsVerified`、`markEmailAsUnverified`、`getEmailForVerification` 和 `sendEmailVerificationNotification` 表达状态与通知。默认模型持久化 `email_verified_at`。注册流程派发 `Registered`，框架监听器仅给仍未验证且声明该能力的用户发送 `VerifyEmail` 邮件。通知复用 Mail 渠道和应用本地化，也保留上游自定义链接和邮件的入口。
- `UrlGenerator::temporarySignedRoute` 生成 `verification.verify` 的临时链接，路由参数是用户模型主键 `id` 和当前验证邮箱的 SHA-1 `hash`，默认 60 分钟。邮箱摘要用于绑定当前地址，签名认证沿用 URL 的 HMAC-SHA256。签发采用配置原值 `app.key`，验证同时接受 `app.previous_keys`，保留 `base64:` 前缀作为签名输入，与 Encrypter 和令牌生成器的密钥解析分开。 `ValidateSignature` 校验签名、期限和请求 URL，按上游支持绝对与相对签名。
- 应用负责注册命名路由 `verification.notice`、`verification.verify`、`verification.send`。验证处理链先执行 `auth`、`signed`，再由 `EmailVerificationRequest::authorize` 校验登录用户主键及当前邮箱摘要。 `fulfill` 持久化验证时间，状态首次改变时派发 `Verified`，重复点击保持幂等。重发入口须通过认证并限流，保留官方文档示例的 `throttle:6,1`。 `verified` 中间件用于受保护页面，按上游规则对 HTML 重定向至通知页，对 JSON 返回 403。路由及页面由应用或入门套件接入。

[固定 VerifyEmail](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Auth/Notifications/VerifyEmail.php) · [固定签名密钥解析](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Routing/RoutingServiceProvider.php) · [固定 EmailVerificationRequest](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Foundation/Auth/EmailVerificationRequest.php)

## 填充与验收顺序

1. 接入 [哈希](encryption-hashing.md)、[认证](auth.md) 及 [数据库](database.md)，实现令牌存储、代理、迁移及过期清理。验收过期、限流、替换、重用、并发消费和写入失败。
2. 接入命名路由与签名，移植旧版固定 PHP 夹具。通过真实 HTTP 验收篡改、过期、密钥轮换、用户和邮箱不匹配、重复验证以及中间件响应。
3. 接入 [邮件和通知](mail-notifications.md) 及 [事件](events.md)，验证默认通知、回调覆盖和事件触发条件。通过后再填三语正文。
