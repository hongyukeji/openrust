# Session、Cookie 与 CSRF 骨架

已声明公开类型与 trait，并预留对应文件。管理器、存储与中间件的执行逻辑随功能簇实现。核对日期为 2026 年 11 月 10 日。命名、默认值和行为以[固定 Laravel 基线](../plans/laravel-rebuild-baseline.md)为准。Rust 的异步存储和请求作用域参考 Goravel 的管理器与驱动分离。 [Laravel Session](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Session) · [Goravel Session 契约](https://github.com/goravel/framework/tree/v1.18.0/contracts/session)

## 目录与公开导入

源码位于 `vendor/openrust/framework/src/`。以下导入均以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 驱动选择和注册 | `session::{SessionManager, SessionServiceProvider}` | `session/{session_manager,session_service_provider}.rs` |
| 请求内状态、载荷加密 | `session::{Store, EncryptedStore, Value, SessionError, SessionFuture, SessionResult}` | `session/{store,encrypted_store,mod}.rs` |
| Session 和存储契约 | `contracts::session::{Session, SessionHandler}` | `contracts/session/` |
| 内置存储 | `session::{FileSessionHandler, DatabaseSessionHandler, CookieSessionHandler, ArraySessionHandler, CacheBasedSessionHandler, NullSessionHandler}` | `session/*_session_handler.rs` |
| Cookie 构造、队列与保护 | `cookie::{Cookie, CookieOptions, CookieJar, CookieError, CookieServiceProvider, CookieValuePrefix}`、`contracts::cookie::{Factory, QueueingFactory}` | `cookie/`、`contracts/cookie/` |
| HTTP 生命周期 | `cookie::middleware::{EncryptCookies, AddQueuedCookiesToResponse}`、`session::middleware::{StartSession, AuthenticateSession}` | `cookie/middleware/`、`session/middleware/` |
| 请求伪造防护 | `foundation::http::middleware::PreventRequestForgery` | `foundation/http/middleware/prevent_request_forgery.rs` |

## Session 与存储驱动

- 应用配置归 [config/session.rs](../../../config/session.rs)。默认驱动为 `database`，表名为 `sessions`，空闲期限为 120 分钟，默认关闭存储载荷加密。配置保留连接、缓存 store、文件路径、Cookie 名称和属性、垃圾回收抽样及锁选项。文件驱动默认路径为 `storage/framework/sessions/`。表迁移由既有 `make:session-table` 契约接入。 [Laravel Session 配置](https://github.com/laravel/framework/blob/v13.40.0/config/session.php) · [Artisan 骨架](artisan.md)
- `SessionManager::driver(&self, name: Option<&str>) -> SessionResult<Store>` 是目标入口。`extend` 登记自定义 handler 工厂。应用共享配置和连接池，每个请求独立创建 Store 和需要请求上下文的 handler。未知驱动返回配置错误。
- `SessionHandler` 声明异步 `read`、`write`、`destroy` 和 `gc`。读取缺失或过期载荷返回 `None`，存储故障返回错误。写入由配置的生命周期约束，`gc` 接收最大生命周期。Rust 使用资源所有权管理 handler，保留 PHP 驱动读写与过期语义。
- `Session` 声明启动、保存、属性读取和写入、闪存、令牌及会话 ID 操作。`exists` 区分键缺失与显式 null，`has` 对 null 返回 false。`flash` 跨到下一次请求，`reflash` 和 `keep` 延长，`save` 推进闪存状态。`migrate` 轮换 ID，`regenerate` 还会轮换 CSRF token。`invalidate` 清空状态并销毁旧 ID，应用按需要另调用 `regenerate_token`。编解码保留身份键和属性类型，具体载荷格式随实现定稿。 [Laravel Store](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Session/Store.php)

| 驱动名 | 目标接线 |
|---|---|
| `database` | `DatabaseSessionHandler` 使用配置连接和表，记录最近活动及请求元数据。用户 ID 保留原始类型。 |
| `file`、`native` | `FileSessionHandler` 写入配置目录。两个名称沿用上游同一文件驱动。 |
| `redis`、`memcached`、`dynamodb`、`apc` | `CacheBasedSessionHandler` 使用相应 Cache store 和 TTL。平台专属后端在对应组件就绪后确定可用性。 |
| `cookie` | `CookieSessionHandler` 使用会话名的 ID Cookie 及以 ID 为名的载荷 Cookie。读取已解密的请求 Cookie，写入和删除经请求 CookieJar。此驱动不参与 Session blocking。 |
| `array`、`null` | 内存驱动和无持久化驱动分别预留。 |

`session.encrypt` 控制后端 Session 载荷加密，`EncryptCookies` 控制 HTTP Cookie 保护。需要保护的 Session ID 和载荷 Cookie 必须通过 Cookie 加解密链。启用会话锁时，以 Session ID 为键覆盖加载、业务执行和保存，异常退出也要释放锁。 [Laravel SessionManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Session/SessionManager.php) · [CookieSessionHandler](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Session/CookieSessionHandler.php) · [固定 Session 文档](https://github.com/laravel/docs/blob/960eedf0911155ad16326ade49c0ea5d18eda0b8/session.md)

## Cookie 与 CSRF

- `Factory` 声明 `make`、`forever`、`forget`。`QueueingFactory` 声明 `queue`、`unqueue`、`get_queued_cookies`。CookieJar 的队列按名称和路径管理。构造、过期和删除保留路径、域、Secure、HttpOnly、SameSite 与 Partitioned 的适用行为。Session Cookie 默认 HttpOnly、SameSite=Lax，`XSRF-TOKEN` 则允许浏览器脚本读取后回传。
- `EncryptCookies` 在请求入口解密 Cookie，在响应回程保护待发送的 Cookie。`CookieValuePrefix` 将加密值绑定到 Cookie 名称，校验失败按无有效 Cookie 处理。中间件使用现有 `contracts::http::Middleware`，目标配置入口为 `Middleware::encrypt_cookies(except)`。 [Laravel CookieJar](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Cookie/CookieJar.php) · [EncryptCookies](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Cookie/Middleware/EncryptCookies.php)
- `PreventRequestForgery` 是固定版本的正式中间件。目标配置入口为 `Middleware::prevent_request_forgery(except, origin_only, allow_same_site)`。GET、HEAD、OPTIONS 及显式排除路径按上游放行。其余请求先检查 `Sec-Fetch-Site`。`same-origin` 可通过，`same-site` 需显式开启。仅来源模式下验证失败返回 403，且不发 `XSRF-TOKEN`。默认模式在来源未通过时回退到 token 校验。
- token 依次取 `_token`、`X-CSRF-TOKEN`、解密后的 `X-XSRF-TOKEN`，与当前 Store 的 token 做常量时间比较。缺失或不匹配返回 419。正常回程按配置发出 `XSRF-TOKEN` Cookie，交给外层加密。 [Laravel PreventRequestForgery](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Http/Middleware/PreventRequestForgery.php) · [Laravel HTTP 异常映射](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Exceptions/Handler.php)

## web 顺序与 SessionGuard

固定上游默认 `web` 组的入站顺序如下。视图错误共享和路由绑定由对应组件接入。`auth.session` 是显式启用项。 [Laravel 中间件配置](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Configuration/Middleware.php)

1. `EncryptCookies` 解密入站 Cookie。
2. `AddQueuedCookiesToResponse` 包裹后续处理，回程追加当前请求的队列。
3. `StartSession` 根据 Session ID 加载 Store 并挂到请求作用域。
4. `ShareErrorsFromSession` 向视图提供已闪存的错误。
5. `PreventRequestForgery` 读取当前 Store 验证请求。
6. `SubstituteBindings` 解析路由绑定。组定义可追加 `auth.session`。合并路由中间件并按优先级排序后，`Authenticate` 和 `AuthenticateSession` 位于 `SubstituteBindings` 之前，`Authorize` 位于其后。 [Laravel HTTP Kernel 优先级](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Http/Kernel.php)

响应回程中，`PreventRequestForgery` 添加适用的 XSRF Cookie，`StartSession` 加入 Session ID Cookie 并完成保存，`AddQueuedCookiesToResponse` 再加入业务 Cookie，最后由 `EncryptCookies` 统一处理出站值。Cookie 驱动在保存时加入载荷 Cookie，因此 Cookie 队列必须包裹 `StartSession`。持久化失败作为错误处理，响应发送前完成这些步骤。 [Laravel StartSession](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Session/Middleware/StartSession.php) · [AddQueuedCookiesToResponse](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php)

SessionGuard 从当前请求取得由 `StartSession` 加载的 Store 和同一 CookieJar。Guard 专属 Session 键存储 `AuthIdentifier`，由 UserProvider 恢复用户。登录写入身份并调用 `regenerate(true)`，CSRF 回程读取轮换后的 token。remember 登录和退出的 Cookie 变更进入同一队列。未配置 Session 驱动时，`StartSession` 直接委托后续处理。需要 SessionGuard 的入口缺少已加载的 Store 或 Cookie 保护时返回明确错误。显式无状态 Guard 走各自的请求解析入口。 [认证骨架](auth.md) · [Laravel SessionGuard](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Auth/SessionGuard.php)

## 填充与验收顺序

1. 先接通 Session 配置、Store、驱动工厂及默认数据库驱动，再验证读取、保存、过期、闪存、ID 轮换和存储失败。
2. 接通 CookieJar、加密和 `StartSession`，验收出站顺序、Cookie 属性、篡改拒绝、Session 锁和请求间隔离。
3. 接通 CSRF、SessionGuard 与可选 `auth.session`，实测来源判定、token 优先级、403 与 419、登录轮换、remember 和退出。功能验收后填写三语正文。
