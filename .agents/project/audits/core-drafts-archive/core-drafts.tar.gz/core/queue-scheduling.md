# 队列与任务调度骨架

以 Laravel 为准、参考 Goravel 实现。已声明公开类型与 trait，并预留对应文件。驱动执行、任务分派与调度运行随功能簇实现。核对日期为 2026 年 11 月 10 日。 [固定 Laravel 基线](../plans/laravel-rebuild-baseline.md) · [Goravel v1.18.0 队列契约](https://github.com/goravel/framework/tree/v1.18.0/contracts/queue) · [Goravel 调度契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/schedule/schedule.go)

## 目录与公开导入

框架源码位于 `vendor/openrust/framework/src/`。下表导入均以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 命名连接和驱动装配 | `queue::{QueueManager, QueueServiceProvider, Queue}`、`contracts::queue::{Factory, Queue}` | `queue/`、`contracts/queue/` |
| 内置驱动 | `queue::{SyncQueue, DatabaseQueue, RedisQueue}` | `queue/{sync_queue,database_queue,redis_queue}.rs`，连接工厂预留在 `queue/connectors/` |
| 任务、载荷与执行上下文 | `contracts::queue::{Job, JobHandler, ShouldQueue}`、`queue::{Payload, Delay, JobOptions, JobContext, QueueError, QueueFuture, QueueResult}` | `contracts/queue/`、`queue/mod.rs`，驱动任务句柄预留在 `queue/jobs/` |
| 消费、重试和失败任务 | `queue::{Worker, WorkerOptions}`、`queue::failed::{FailedJob, FailedJobProviderInterface}` | `queue/{worker,worker_options}.rs`、`queue/failed/` |
| 调度定义和互斥 | `console::scheduling::{Schedule, Event, CallbackEvent, EventMutex, SchedulingMutex}` | `console/scheduling/` |
| Artisan 命令 | `queue::console::WorkCommand`、`console::scheduling::ScheduleRunCommand` | `queue/console/work_command.rs`、`console/scheduling/schedule_run_command.rs` |

应用任务放在 `app/jobs/`，调度定义放在 [routes/console.rs](../../../routes/console.rs)，由应用启动装配显式登记。Rust 使用任务注册表将稳定的任务名映射到类型化处理器。载荷保存任务名、版本、数据、UUID 和运行选项，以供独立 Worker 解析。同一任务的 UUID 与后端记录 ID 分开。 [Laravel Queue 契约](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Contracts/Queue) · [Goravel Job 注册契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/queue/job.go)

## QueueManager 与驱动

配置归 [config/queue.rs](../../../config/queue.rs)。`Factory::connection(name)` 取得命名 Queue，`QueueManager` 复用已解析连接，目标 `extend` 登记自定义连接工厂。`QUEUE_CONNECTION` 未设置时默认 `database`，具体连接可配置默认队列名。连接名与队列名分别解析。 [Laravel QueueManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/QueueManager.php) · [固定队列配置](https://github.com/laravel/framework/blob/v13.40.0/config/queue.php)

| 驱动 | 目标契约 |
|---|---|
| `sync` | 在分派调用中执行任务，失败回传给调用方。延迟分派沿用上游立即执行语义，配置了提交后分派时等待提交。无需启动 Worker。 |
| `database` | 复用数据库连接，在 `jobs` 表保存可用时间、预约和尝试次数，按事务保护预约、释放和删除。 |
| `redis` | 通过 RedisManager 解析命名连接，用原子操作维护等待、延迟和已预约任务，按配置支持阻塞读取。集群键使用同一哈希槽，空队列等待不阻塞退出处理。 |

`Queue` trait 声明 `size`、`push`、`later` 与 `pop`。延迟支持相对时长和绝对时间。出队返回属于一次预约的 Job，暂时无任务返回 `None`。入队返回可选后端 ID，适配没有持久记录的 sync。批量入队和原始载荷入口随驱动实现核对。数据库和 Redis 的 `retry_after` 基线为 90 秒，连接级 `after_commit` 默认 false。启用提交后分派时，外层提交才入队，回滚丢弃待分派任务。数据库表由既有 Artisan 迁移生成器接入。 [Laravel SyncQueue](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/SyncQueue.php) · [DatabaseQueue](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/DatabaseQueue.php) · [RedisQueue](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/RedisQueue.php) · [数据库骨架](database.md) · [Redis 骨架](cache-redis.md)

## Job、Worker、重试与失败

- 后端 `Job` 声明 `fire`、`delete`、`release`、`fail` 和任务状态查询。应用 `JobHandler::handle` 接收载荷和本次尝试的作用域。Worker 成功后确认，显式释放或可重试异常按延迟重新可用，已删除或已释放的预约不再重复确认。预约失效后的写入不能覆盖后继预约。
- Worker 的目标运行入口保留 `daemon` 和 `run_next_job`。每次处理隔离任务作用域。按任务与 Worker 选项解析 `tries`、`retry_until`、`max_exceptions`、`backoff`、`timeout` 和 `fail_on_timeout`。期限和次数优先级遵循固定源码，配置了 `retry_until` 时按该截止条件处理尝试上限。Worker 超时应短于 `retry_after`，超时和退出必须停止或隔离仍在运行的工作，避免与后继预约并行写入。
- `FailedJobProviderInterface` 声明记录、列表、查找、删除和清理。默认 `database-uuids` 使用 `failed_jobs` 表。终态失败走任务失败钩子与事件记录。失败存储、确认和重新入队跨后端时须分别处理部分失败。手动重试使用原连接、队列与任务载荷，按上游重置尝试次数，重新入队成功后才移除失败记录。 [Laravel Worker](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/Worker.php) · [失败记录契约](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/Failed/FailedJobProviderInterface.php) · [RetryCommand](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/Console/RetryCommand.php)

## Schedule 与 Artisan 接线

- `Schedule` 预定入口为 `call`、`command`、`job` 和 `exec`。分别登记回调、Artisan 命令、队列任务和外部命令。命令与参数独立传入，队列入口预定为 `job(&mut self, payload: Payload, queue: Option<&str>, connection: Option<&str>) -> &mut CallbackEvent`。`Event` 持有频率、时区、运行环境和条件。保留 cron、每分钟及子分钟频率。调度按注入时钟判断到期，队列任务走同一 QueueManager。
- `without_overlapping` 通过 `EventMutex` 约束同一事件的并发运行，默认过期为 1440 分钟。`on_one_server` 通过 `SchedulingMutex` 在给定时间槽选出一个执行者，采用共享 Cache Store。这两种锁的键和释放时机分别验收。子分钟任务按上游在当前分钟持续评估，保留中断入口。 [Laravel Schedule](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Console/Scheduling/Schedule.php) · [固定调度文档](https://github.com/laravel/docs/blob/960eedf0911155ad16326ade49c0ea5d18eda0b8/scheduling.md)

| 命令 | 目标接线 |
|---|---|
| `artisan queue:work [connection]` | `WorkCommand` 解析连接和 `--queue`，将 `--once` 交给 `run_next_job`，其余按 Worker 持续消费。基线包括 `--tries=1`、`--timeout=60`、`--sleep=3`、`--backoff=0`，并保留空队列、最大任务数和运行时长的停止选项。优雅退出在当前任务边界停止接单。 |
| `artisan schedule:run` | `ScheduleRunCommand` 取得应用登记的 Schedule，执行当前到期任务，`--whisper` 仅隐藏无到期任务提示。命令调用、队列分派和回调共用各自的框架入口。 |
| `artisan queue:failed`、`queue:retry`、`queue:forget`、`queue:flush`、`queue:restart` | 预留对应命令文件。失败任务管理走失败记录契约，Worker 重启信号走缓存，并在安全任务边界生效。 |

命令接入现有 Artisan 注册表。当前 `queue:work` 和 `schedule:run` 仍按占位状态显示。 [Laravel WorkCommand](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Queue/Console/WorkCommand.php) · [ScheduleRunCommand](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Console/Scheduling/ScheduleRunCommand.php) · [Artisan 骨架](artisan.md)

## 填充与验收顺序

1. 接通任务注册和 sync，再实现数据库与 Redis 的预约、释放和确认。验证延迟、重复投递、事务提交与取消边界。
2. 实现 Worker 和失败任务，验证重试、超时、失败记录、手动重试与退出。通过实际 `queue:work` 命令验收。
3. 接通 Schedule、缓存互斥与 `schedule:run`，验证时区、到期、重叠和多实例竞争。功能验收后填写三语正文。
