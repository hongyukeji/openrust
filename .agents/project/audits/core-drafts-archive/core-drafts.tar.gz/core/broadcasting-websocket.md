# 广播与 WebSocket 骨架

应用广播按 Laravel Framework v13.40.0。WebSocket 服务端对照支持 Laravel 13 的 Reverb v1.8.1，固定提交 `70e3d28ed31466da34de0c055f3681b75a5a538c`。固定 Goravel v1.18.0 的框架和应用树均无广播或 WebSocket 模块，其 `Runner` 仅作为同进程启动、信号传递和关停顺序的参考。 [Laravel 广播源码](https://github.com/laravel/framework/tree/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Broadcasting) · [Reverb 源码](https://github.com/laravel/reverb/tree/70e3d28ed31466da34de0c055f3681b75a5a538c) · [Goravel Application](https://github.com/goravel/framework/blob/a554ced468cada50a269780692a0491e5f9e3a11/foundation/application.go)

## openrust-v0.x 复用核对

已只读检查 `openrust-v0.x` 的 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。以下用例用于后续移植，本轮未重跑旧版测试。

| 旧版路径 | 可复用的实现与用例 |
| --- | --- |
| `vendor/openrust/framework/src/realtime.rs` | 提取 Origin 检查、连接与消息上限、有界发送队列、心跳和受管理的取消。保留慢连接遇到关闭或期限到达时能退出的测试。 |
| `vendor/openrust/framework/src/realtime/validator_tests.rs` | 提取连接被撤销后停止发送及关闭的测试思路。旧 JWT 校验按实际启用的身份策略选择，频道授权统一走当前 AuthManager。 |
| `tests/consumers/realtime/tests/cluster.rs` | 改写双进程 Redis 投递、拒绝恶意 Origin、共享传输故障、SIGTERM 关闭连接和释放端口的用例。客户端改用 Reverb/Pusher 帧。 |

旧版用数值用户 ID 定向投递，WebSocket 只处理控制帧，另有 SSE 入口。本批采用频道订阅、签名和 Pusher 帧契约。旧 `realtime.*` 配置、消息封套、SSE 和 URL 无兼容承诺。

## 目录与公开接口

| 职责 | 公开路径 | 文件 |
| --- | --- | --- |
| 广播连接与服务装配 | `openrust::broadcasting::{BroadcastManager, BroadcastServiceProvider}`、`openrust::contracts::broadcasting::{Factory, Broadcaster}` | 框架的 `src/broadcasting/` 和 `src/contracts/broadcasting/` |
| 频道及授权 | `openrust::broadcasting::{Channel, PrivateChannel, PresenceChannel, BroadcastController}`、`openrust::contracts::broadcasting::ChannelHandler`、`openrust::support::facades::Broadcast` | `broadcasting/`、`support/facades.rs`、[routes/channels.rs](../../../routes/channels.rs)、[app/broadcasting/mod.rs](../../../app/broadcasting/mod.rs) |
| 事件交付 | `openrust::contracts::broadcasting::{ShouldBroadcast, ShouldBroadcastNow}`、`openrust::broadcasting::BroadcastEvent` | `contracts/broadcasting/mod.rs`、`broadcasting/broadcast_event.rs` |
| 广播连接配置 | `broadcasting.default`、`broadcasting.connections.<name>` | [config/broadcasting.rs](../../../config/broadcasting.rs) |
| 可选 Reverb 包 | Cargo 包 `openrust-reverb`，Rust 导入 `openrust_reverb::servers::reverb::Server`，`protocols::pusher` 承载协议 | [vendor/openrust/reverb/src/lib.rs](../../../vendor/openrust/reverb/src/lib.rs)、[config/reverb.rs](../../../config/reverb.rs) |

框架公开路径和 trait 已声明。Manager、Facade、Controller 和 Provider 的方法按下面契约填充。Reverb 目录现为预留，Cargo 依赖在实现阶段接入。

## 频道注册与授权

- 应用用 `Application::configure(...).withBroadcasting(...)` 接入 `routes/channels.rs` 的静态注册函数和可选路由属性。注册函数用 `Broadcast::channel(pattern, handler, options)`，类式频道放在 `app/broadcasting/`，实现 `ChannelHandler::join`。匹配 `orders.{orderId}` 这类模式后解析绑定参数，授权仍由注册的处理器决定。默认使用当前请求的 Guard，频道可按顺序指定 Guard。
- 注册广播时，`BroadcastManager::routes` 默认在 `web` 组提供 `GET/POST /broadcasting/auth`。按固定源码仅对此路由移除请求伪造防护中间件，保持频道授权。若应用采用显式 Bearer 认证，可用上游同样的路由属性入口指定前缀和中间件。独立的 `userRoutes` 按需提供 `GET/POST /broadcasting/user-auth`。
- 公开频道订阅无需签名。私有频道用当前身份和频道参数作授权，成功后签名绑定应用、`socket_id` 和频道名。Presence 另返回稳定用户 ID 与白名单成员数据，签名覆盖成员数据。保留字符串及整数身份语义，缺身份、未登记频道或授权拒绝时不得发签名。私有及 Presence 前缀由协议适配器添加，应用只填写逻辑名。 [BroadcastManager](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Broadcasting/BroadcastManager.php) · [PusherBroadcaster](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Broadcasting/Broadcasters/PusherBroadcaster.php)

## 事件与队列

- Dispatcher 在调用事件监听器前检查 `ShouldBroadcast` 和 `broadcastWhen`。Rust 通过静态事件注册保留类型擦除前的广播描述与标记，Worker 通过显式注册的任务类型和可序列化载荷执行。默认封装为 `BroadcastEvent` 入队，`ShouldBroadcastNow` 同步派发。广播连接与队列连接分别选择，`broadcastQueue` 优先于通用队列名。
- `broadcastOn` 提供频道，`broadcastAs` 缺省用事件公开名，`broadcastWith` 缺省时使用事件声明的可广播字段。PHP 的公开属性反射用 Rust 显式声明替代，字段和值与上游对应，序列化范围由测试核对。 `toOthers` 读取请求的 `X-Socket-ID`，只排除该来源连接。
- 实现 `ShouldDispatchAfterCommit` 时沿用事件的提交边界。队列连接或任务要求 `after_commit` 时沿用队列的提交边界。分别验证成功提交、回滚和失败重试，避免回滚事务产生广播。 [Laravel Dispatcher](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Events/Dispatcher.php) · [BroadcastEvent](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Broadcasting/BroadcastEvent.php) · [队列骨架](queue-scheduling.md) · [事件骨架](events.md)

## WebSocket 运行方式

- **默认配置。** 保留 Laravel 的 `BROADCAST_CONNECTION=null`。本地服务由 OpenRust 的 `reverb.enabled` 显式启用，默认关闭。启用并配置后，`cargo run` 或发布二进制默认随 HTTP 一起启动 WebSocket，同一个 Tokio 运行时管理两个监听器。常规 Artisan 命令和只配置远端发布连接的应用均不会绑定 WebSocket 端口。
- **独立运行。** OpenRust 的运行模式选项定为 `reverb.mode`，本地服务启用时默认 `embedded`，部署可显式选 `standalone`。独立模式由同一应用二进制执行 `artisan reverb:start`，沿用 `--host`、`--port`、`--path`、`--hostname`、`--debug`。仅启动 Reverb，应用 HTTP 继续承担频道授权。预留 `reverb:restart`，独立模式按上游让进程管理器拉起，内嵌模式的部署重启由主应用管理。
- **协议与生命周期。** 区分 `REVERB_SERVER_HOST/PORT` 监听地址与 `REVERB_HOST/PORT/SCHEME` 发布目标。服务端处理 `/app/{appKey}` 升级和签名后的 `/apps/{appId}/...` 发布请求，按应用隔离凭据、Origin、频道和成员。发布连接与 WebSocket 监听互相独立，Redis 用于可选的跨进程扩展。内嵌监听绑定失败随应用启动报错，关停时停止接受新连接、关闭并排空已有连接、释放监听端口。 [Laravel Reverb 文档](https://laravel.com/docs/13.x/reverb) · [固定 StartServer](https://github.com/laravel/reverb/blob/70e3d28ed31466da34de0c055f3681b75a5a538c/src/Servers/Reverb/Console/Commands/StartServer.php)

## 填充与验收顺序

1. 接通广播连接、频道授权和 `channel:list`。覆盖默认空广播、缺身份、拒绝授权、请求作用域隔离和 Presence 数据签名。
2. 接通事件、同步和队列广播。验证条件、事件名、载荷、事务提交与回滚、失败重试和 `toOthers`。
3. 接入 Reverb，用真实 Echo/Pusher 客户端覆盖三类频道、两种运行方式、普通 Artisan 不占端口、绑定失败、关停和双进程 Redis。验收后填写三语 Broadcasting 与 Reverb 正文。
