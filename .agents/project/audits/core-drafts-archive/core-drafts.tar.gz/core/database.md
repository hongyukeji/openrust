# 数据库骨架

当前状态为骨架定稿。框架 crate 已声明公开类型和可编译的 trait 签名。本文的构造与执行方法随各功能簇填充。核对日期为 2026 年 11 月 10 日。

以[固定 Laravel 基线](../plans/laravel-rebuild-baseline.md)为准。连接管理、SQL 编译、Schema 和迁移语义对照 [Laravel Framework v13.40.0 数据库源码](https://github.com/laravel/framework/tree/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Database)。异步驱动接口和迁移静态注册参考 [Goravel v1.18.0 数据库契约](https://github.com/goravel/framework/tree/a554ced468cada50a269780692a0491e5f9e3a11/contracts/database) 中的连接上下文、显式错误和迁移注册。Rust 的异步 I/O 由框架契约表达。

## 目录与公开路径

下表源码相对 `vendor/openrust/framework/src/database/`。`query::Builder` 与 `schema::Builder` 各保留上游命名，用模块区分。

| 职责 | Rust 公开路径 | 源文件 |
|---|---|---|
| 连接解析、默认连接和池生命周期 | `openrust::database::{DatabaseManager, ConnectionResolverInterface}` | `database_manager.rs`、`connection_resolver_interface.rs` |
| 逻辑连接、语句与事务 | `openrust::database::{Connection, ConnectionInterface}` | `connection.rs`、`connection_interface.rs` |
| 数据库输入输出与错误 | `openrust::database::{Value, Row, DatabaseError, DatabaseResult, DatabaseFuture}` | `mod.rs` |
| 连接工厂和驱动适配 | `openrust::database::connectors::ConnectionFactory` | `connectors/connection_factory.rs` |
| 框架服务注册 | `openrust::database::{DatabaseServiceProvider, MigrationServiceProvider}` | `database_service_provider.rs`、`migration_service_provider.rs` |
| 查询构造、联结、显式 SQL 表达式 | `openrust::database::query::{Builder, JoinClause, Expression, Record}` | `query/` |
| Schema 编排与元数据读取 | `openrust::database::schema::{Builder, Column, Index, ForeignKey}` | `schema/builder.rs`、`schema/mod.rs` |
| 表结构定义及修饰 | `openrust::database::schema::{Blueprint, ColumnDefinition, IndexDefinition, ForeignIdColumnDefinition, ForeignKeyDefinition}` | `schema/` |
| 迁移契约、运行、回滚及生成 | `openrust::database::migrations::{Migration, Migrator, MigrationCreator, MigrationResult, RunOptions, RollbackOptions}` | `migrations/` |
| 迁移账本契约与实现 | `openrust::database::migrations::{MigrationRepositoryInterface, DatabaseMigrationRepository, MigrationRecord}` | `migrations/migration_repository_interface.rs`、`migrations/database_migration_repository.rs` |

驱动文件按职责预留在 `*_connection.rs`、`connectors/`、`query/grammars/`、`query/processors/` 和 `schema/grammars/`，覆盖 MariaDB、MySQL、PostgreSQL、SQLite 和 SQL Server。文件名用 Rust 风格，公开驱动类型在各方言填充时按上游的 `MariaDb`、`MySql`、`Postgres`、`SQLite` 和 `SqlServer` 前缀定名。驱动连接、连接池及 SQL AST 的内部表示随驱动功能定稿，应用接口不依赖具体驱动库。

根应用在 [config/database.rs](../../../config/database.rs) 汇总配置，在 [database/migrations/mod.rs](../../../database/migrations/mod.rs) 注册迁移。Artisan 数据库命令位于框架的 `database/console/`，`make:migration` 委托 `MigrationCreator`。Seeder、Factory、Eloquent 和分页随后各自定稿。 [Artisan 生成器契约](artisan.md)

## 连接管理

- `DatabaseServiceProvider` 从配置仓储装配 `DatabaseManager` 和 `ConnectionFactory`。配置保留 `database.default`、`database.connections.<name>`、`database.migrations.table` 层级。`DB_CONNECTION` 选择默认命名连接，框架基线回退到 `sqlite`，文件位置为应用根目录下的 `database/database.sqlite`，默认启用外键约束。连接 URL 与分项配置的合并对照上游解析器。 [Laravel 数据库配置](https://github.com/laravel/framework/blob/v13.40.0/config/database.php) · [URL 配置解析](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/ConfigurationUrlParser.php)
- `connection(&self, name: Option<&str>) -> DatabaseResult<Connection>` 按名称解析，缺省使用默认连接，首次实际 I/O 时建立物理连接。命名连接可共享连接池。事务层级和写入标记保存在请求或任务的逻辑连接内，同一工作作用域内使用同一逻辑连接，防止其他作用域误用事务或粘滞读状态。名称或驱动无效时返回明确错误。 [Laravel DatabaseManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/DatabaseManager.php) · [ConnectionFactory](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Connectors/ConnectionFactory.php)
- `get_default_connection`、`set_default_connection` 已声明。管理器的异步目标方法为 `disconnect(&self, name: Option<&str>) -> DatabaseResult<()>`、`purge(&self, name: Option<&str>) -> DatabaseResult<()>` 和 `reconnect(&self, name: Option<&str>) -> DatabaseResult<Connection>`。断开保留已解析的连接定义，清除同时移除缓存登记，重连更新后续连接使用的资源。事务中的句柄不能悄悄切换物理连接。
- `select`、`select_one`、`scalar` 默认允许使用读连接。事务内、显式选用写连接，或启用 `sticky` 后同一作用域发生写入时，读取走写连接。`select_one` 无行返回 `None`。`scalar` 无行返回 SQL NULL，多列时返回错误。`insert`、`statement` 和 `unprepared` 返回执行布尔值，`update`、`delete` 和 `affecting_statement` 返回影响行数。绑定值保留 SQL NULL、二进制、整数、精确小数和时态类型，错误应保留可定位的阶段与驱动原因，过滤连接凭据和敏感绑定。 [Laravel Connection](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Connection.php)
- 事务目标入口为 `transaction<T>(&mut self, attempts: u32, callback: impl for<'tx> FnMut(&'tx mut dyn ConnectionInterface) -> DatabaseFuture<'tx, DatabaseResult<T>> + Send) -> DatabaseResult<T>`，以异步方法提供，默认尝试一次。回调借用同一连接，成功提交，失败回滚并保留原始错误。嵌套事务按驱动能力使用保存点，遵循固定上游对并发错误与断连的处理。取消或丢弃 future 后，连接恢复到可用状态或从池中淘汰后才能再次借出。只在可安全重试的边界重试，提交结果未知时不自动重放。 [Laravel 事务实现](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Concerns/ManagesTransactions.php) · [Goravel DB 与 Tx](https://github.com/goravel/framework/blob/v1.18.0/contracts/database/db/db.go)

## 查询构造器

`ConnectionInterface::table(&mut self, table: &str, alias: Option<&str>)` 返回借用同一连接的 `query::Builder<'_>`。构造操作修改当前 Builder 并返回可链式调用的借用。Rust 保留上游职责和方法名，以显式参数代替 PHP 重载。保留关键字 `where` 在 Rust 调用时写作 `r#where`，等值条件另提供 `where_eq`。

| 操作 | 首批目标签名与契约 |
|---|---|
| 投影与来源 | `select(&mut self, columns: &[&str]) -> &mut Self`、`add_select`、`from`。没有显式投影时默认 `*`。原生表达式从 `Expression` 或 `select_raw(sql, bindings)` 进入 |
| 条件 | `r#where(&mut self, column: &str, operator: &str, value: Value) -> DatabaseResult<&mut Self>`，`or_where` 同形。等于 NULL 走空值条件，`where_in`、`where_null`、`where_column`、分组条件与空集合行为按上游编译 |
| 联结与聚合 | `join` 和 `left_join` 使用 `JoinClause` 表达列比较与绑定值，`group_by`、`having` 和聚合操作沿用上游职责 |
| 排序、分页窗口与锁 | `order_by` 接收可选 `asc` / `desc`，默认升序。保留 `limit`、`offset`、`lock_for_update` 与 `shared_lock`。锁定读取走写连接 |
| 编译与绑定 | `to_sql(&self) -> DatabaseResult<String>`、`get_bindings(&self) -> Vec<Value>`。按子句顺序生成对应 SQL 与绑定，调试输出保留上游占位符形式。驱动占位符在执行边界转换 |
| 读取 | 异步 `get(&mut self, columns: Option<&[&str]>) -> DatabaseResult<Vec<Row>>`、`first`、`find` 返回可选行，`value` 返回单列值，`count` 和 `exists` 返回数量和布尔值。无行与执行失败分别表达 |
| 写入 | 异步 `insert(&mut self, rows: &[Record]) -> DatabaseResult<bool>`、`update(&mut self, values: &Record) -> DatabaseResult<u64>`、`delete(&mut self, id: Option<Value>) -> DatabaseResult<u64>`。保留 `insert_get_id`、`insert_or_ignore`、`upsert`，其返回值及冲突处理按驱动验收 |

标识符引用、占位符及方言能力由 Grammar 处理。普通值绑定，显式 raw 表达式才接受 SQL。查询编译与执行分开验证，检查绑定次序和数目，避免拼接用户值或用字符串替换破坏引号与注释中的占位符。Processor 负责驱动结果归一化，例如生成主键。窗口 `limit/offset` 归 Query，分页对象及流式 `cursor` 的资源释放另随对应能力填充。 [Laravel Query Builder](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Query/Builder.php) · [方言 Grammar](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Database/Query/Grammars)

## Schema

`ConnectionInterface::get_schema_builder(&mut self) -> schema::Builder<'_>` 保留当前连接和事务上下文。应用侧 Facade 预定为 `openrust::support::facades::{DB, Schema}`，随 Facade 的容器解析和作用域契约接入。`Schema::connection` 先解析命名连接，再使用同一 Schema Builder。

- **建表与修改。** `create`、`table` 使用异步目标签名 `(&mut self, table: &str, define: impl FnOnce(&mut Blueprint) + Send) -> DatabaseResult<()>`。闭包同步收集列、索引和约束，随后由驱动 Schema Grammar 编译并执行 DDL。保留 `drop`、`drop_if_exists`、`rename`、`drop_columns` 与外键开关接口。
- **表结构定义。** `Blueprint` 首批目标方法为 `id`、`string`、`text`、`integer`、`boolean`、`decimal`、`timestamps`、`primary`、`unique`、`index`、`foreign_id`、`foreign`。例如 `string(&mut self, column: &str, length: Option<u32>) -> &mut ColumnDefinition`，`foreign_id(&mut self, column: &str) -> &mut ForeignIdColumnDefinition`。列修饰保留 `nullable`、`default`、`change`，外键修饰保留 `constrained`、`references` 及删除和更新动作。默认长度和派生命名按上游核验。
- **结构检查。** `has_table`、`has_column`、`has_index` 异步返回 `DatabaseResult<bool>`，以 `false` 表示不存在。`get_columns`、`get_indexes` 和 `get_foreign_keys` 分别返回结构化 `Column`、`Index`、`ForeignKey` 列表。按各驱动验证 Schema 限定名、索引顺序、类型与默认值，并区分方言不支持的操作与执行失败。

连接 Grammar、查询 Grammar 与 Schema Grammar 按各自职责预留。DDL 是否可事务化由 Schema Grammar 报告，SQLite 表重建和元数据恢复随受影响操作验收。 [Laravel Schema Builder](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Schema/Builder.php) · [Blueprint](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Schema/Blueprint.php) · [Goravel Schema 契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/database/schema/schema.go)

## 迁移

- **注册与生成。** 迁移位于 `database/migrations/<时间戳>_<name>.rs`。目标注册入口为 `Migrator::register(&mut self, path: &Path, migration: Box<dyn Migration>) -> DatabaseResult<()>`。注册项保留源路径，用去掉扩展名的文件名识别迁移并检测冲突。应用或扩展在编译时纳入迁移模块，再通过显式注册加入运行计划。`--path` 筛选已注册路径，`--realpath` 表示传入绝对路径。文件保留上游的 `YYYY_MM_DD_HHMMSS` 时间戳，生成器用 `#[path = "…"]` 将数字开头的文件映射到合法的 Rust 模块名。重新编译后该迁移可执行。 [Laravel MigrationCreator](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Migrations/MigrationCreator.php) · [Goravel 迁移注册](https://github.com/goravel/framework/blob/v1.18.0/contracts/database/schema/schema.go)
- **执行。** `Migration::up` / `down` 借用所选连接，`get_connection` 可指定迁移连接。`should_run` 默认语义为允许，事务默认语义为启用，Rust 生成模板显式声明二者。迁移默认按文件名升序，成功后才写入账本，跳过的迁移保持待执行。`RunOptions::step` 让每条迁移占用单独批次。只有迁移允许且 Schema Grammar 支持时才包装 DDL 事务。
- **回滚与预演。** `rollback` 默认回退最后一批。正数 `step` 优先于指定 `batch`，`reset` 按反序撤销全部已执行迁移。`down` 成功后才移除账本记录。`pretend` 通过连接捕获迁移 SQL，迁移语句与账本无写入，命令初始化和预演边界按上游单独验收。
- **账本与命令。** 默认表 `migrations`，记录 `id`、`migration` 和 `batch`。`MigrationRepositoryInterface` 声明查询、批次、建表和删除接口，连接由运行命令选择。迁移可覆写 DDL 连接，账本仍归命令所选连接，不能把跨连接操作假定为原子。生产确认、`--force`、`--isolated` 与输出归 Artisan 适配。 [Laravel Migrator](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Migrations/Migrator.php) · [数据库迁移账本](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Migrations/DatabaseMigrationRepository.php) · [迁移命令](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Console/Migrations/MigrateCommand.php)

| 所属类型 | 目标执行签名 |
|---|---|
| `Migrator` | `async fn run(&mut self, paths: &[PathBuf], options: RunOptions) -> DatabaseResult<Vec<PathBuf>>` |
| `Migrator` | `async fn rollback(&mut self, paths: &[PathBuf], options: RollbackOptions) -> DatabaseResult<Vec<PathBuf>>` |
| `Migrator` | `async fn reset(&mut self, paths: &[PathBuf], pretend: bool) -> DatabaseResult<Vec<PathBuf>>` |
| `MigrationCreator` | `fn create(&self, name: &str, path: &Path, table: Option<&str>, create: bool) -> DatabaseResult<PathBuf>` |

## 填充与验收顺序

1. 先实现配置、连接解析、读写路由与事务。验收默认连接、未知连接、读写隔离、重连、保存点及取消恢复。
2. 再实现 Query Grammar 与 Processor，用上游 SQL 和绑定断言做对照，并实际执行读写、NULL、联结、聚合、锁与主键返回。
3. 补齐 Schema 和数据库账本后接入迁移。覆盖建改表、结构读取、批次与回滚、预演、事务化 DDL 差异和生产确认。
4. 日常数据库验收用 MySQL 8.4，发布前验证固定 Laravel 兼容基线及多驱动行为。基线为 MariaDB 10.3+、MySQL 5.7+、PostgreSQL 10.0+、SQLite 3.26.0+、SQL Server 2017+。验收随实现填充，三语数据库正文目前保留占位。 [固定 Laravel 数据库文档](https://github.com/laravel/docs/blob/960eedf0911155ad16326ade49c0ea5d18eda0b8/database.md)
