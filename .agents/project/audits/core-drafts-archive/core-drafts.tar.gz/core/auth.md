# 认证与授权骨架

当前阶段已声明公开类型和 trait，并预留对应文件。构造、注册和运行行为随功能簇实现。核对日期为 2026 年 11 月 10 日。公开行为以[固定 Laravel 基线](../plans/laravel-rebuild-baseline.md)为准，显式工厂和请求上下文参考 Goravel v1.18.0。 [Laravel 认证源码](https://github.com/laravel/framework/tree/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Auth) · [Goravel 认证工厂](https://github.com/goravel/framework/blob/v1.18.0/contracts/auth/auth.go)

## 目录与公开导入

框架源码位于 `vendor/openrust/framework/src/`。下表导入均以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 认证服务注册、Guard 解析和切换 | `auth::{AuthManager, AuthServiceProvider}`、`contracts::auth::Factory` | `auth/{auth_manager,auth_service_provider}.rs`、`contracts/auth/factory.rs` |
| 当前身份与登录状态 | `contracts::auth::{Guard, StatefulGuard, Authenticatable}` | `contracts/auth/` |
| 内置 Guard | `auth::{SessionGuard, RequestGuard, TokenGuard}` | `auth/{session_guard,request_guard,token_guard}.rs` |
| 用户查找与凭据校验 | `contracts::auth::UserProvider`、`auth::{EloquentUserProvider, DatabaseUserProvider}` | `contracts/auth/user_provider.rs`、`auth/{eloquent_user_provider,database_user_provider}.rs` |
| 身份键、凭据、失败与异步返回 | `auth::{AuthIdentifier, Credentials, AuthError, AuthResult, AuthFuture}` | `auth/mod.rs` |
| 能力注册、判定、策略与授权响应 | `auth::access::{Gate, Policy, Argument, Response, AuthorizationError}`、`contracts::auth::access::Gate` | `auth/access/`、`contracts/auth/access/` |
| HTTP 中间件 | `auth::middleware::{Authenticate, RedirectIfAuthenticated, Authorize}` | `auth/middleware/` |
| Session 接线 | `session::Store`、`session::middleware::StartSession` | `session/store.rs`、`session/middleware/start_session.rs` |

应用模型位于 `app/models/`，应用策略位于 `app/policies/`，业务能力和策略由应用 Provider 注册。配置入口为 `config/auth.rs` 与 `config/session.rs`。上游契约在 `Contracts/Auth`，运行类型在 `Auth` 与 `Auth/Access`。 [Laravel Auth 契约](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Contracts/Auth)

## AuthManager、Guard 与身份

- `AuthServiceProvider` 在应用启动时登记 Guard 和 UserProvider 工厂以及 Gate 注册表。配置保留 `auth.defaults.guard`、`auth.guards.<name>.driver`、`auth.guards.<name>.provider` 与 `auth.providers.<name>`。目标默认是 `web` Guard，驱动为 `session`，用户 Provider 为 `users`，驱动为 `eloquent`。
- `Factory::guard(&mut self, name: Option<&str>)` 解析指定 Guard 或默认 Guard。`should_use(&mut self, name: &str)` 选择当前请求的默认 Guard，Gate 和请求用户解析共用该选择。全局共享工厂和不可变配置，已解析 Guard 及用户缓存限定在请求内。未知 Guard、驱动或 Provider 返回可定位错误。
- `AuthManager::extend` 和 `provider` 分别登记 Guard 工厂和 UserProvider 工厂。`via_request` 以当前请求为输入登记 `RequestGuard` 用户解析器。工厂在装配时登记，Guard 按请求延迟创建。Rust 通过显式 `stateful_guard` 获取 `StatefulGuard`，调用前校验驱动能力。
- `Guard::user` 返回可选的已解析用户，`has_user` 仅检查已缓存用户。`check`、`guest` 走用户解析，`validate` 只验证凭据，`set_user` 只更新 Guard 当前用户。`StatefulGuard` 另声明 `attempt`、`login`、`login_using_id`、`once`、`once_using_id`、`via_remember` 和 `logout`。`once` 系列只影响当前请求。
- `Authenticatable` 提供主键、密码哈希和 remember token 的字段契约。`AuthIdentifier` 保留字符串、有符号和无符号整数身份，Session 和 Provider 使用同一身份表示。凭据错误、无已认证用户和后端失败分别处理，错误和日志过滤密码、remember token 等敏感值。 [Laravel AuthManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Auth/AuthManager.php) · [认证默认配置](https://github.com/laravel/framework/blob/v13.40.0/config/auth.php)

## UserProvider 与 Eloquent

| 契约 | 行为 |
|---|---|
| `retrieve_by_id` | 使用 `AuthIdentifier` 查找用户，保留模型配置的主键与连接。 |
| `retrieve_by_token`、`update_remember_token` | 使用身份和 remember token 恢复用户，并按 Guard 流程持久化令牌。更新成功后同步返回给 Guard 的模型状态。 |
| `retrieve_by_credentials` | 依据允许的标识字段和约束查询。密码用于独立校验，不进入用户查询条件。 |
| `validate_credentials`、`rehash_password_if_required` | 由框架 Hashing 契约校验密码哈希，在适用登录流程下升级哈希。失败原因区分认证不通过与服务错误。 |

`EloquentUserProvider<M>` 要求 `M: Model + Authenticatable`。应用在装配时登记 `auth.providers.<name>.model` 对应的 Rust 模型类型。Provider 使用现有 Eloquent Builder 水合用户并沿用模型作用域，通过模型持久化入口更新哈希与 remember token。`DatabaseUserProvider` 对应 `database` 驱动，使用配置的表和底层 Query Builder。两者返回同一 `Authenticatable` 契约。 [EloquentUserProvider](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Auth/EloquentUserProvider.php) · [DatabaseUserProvider](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Auth/DatabaseUserProvider.php) · [本项目 Eloquent 骨架](eloquent.md)

## Session 与 HTTP 接线

1. `web` 中间件链先处理入站 Cookie 和响应 Cookie 队列，再由 `StartSession` 加载当前请求的 `Store`。CSRF 使用同一 Session。应用为当前请求装配 AuthManager，SessionGuard 和响应持久化使用同一份 Session 状态。
2. SessionGuard 优先按 Guard 专属 Session 键中的身份调用 UserProvider。需要时按 Laravel 的 recaller 流程读取受保护的 remember Cookie。登录写入身份后调用 `Store::regenerate(true)`，轮换 Session ID 和 CSRF token。退出清理 Guard 的 Session 身份与 Cookie，按上游规则轮换 remember token。应用退出流程仍可显式调用 Session `invalidate` 与 `regenerate_token`。
3. `auth` 中间件按配置顺序试选 Guard，通过后用 `should_use` 固定本请求的身份来源。`guest` 用于已认证用户的重定向，`can` 调用 Gate。未登录按请求类型返回重定向或 401，授权拒绝默认 403，也可使用授权响应指定的状态。
4. Laravel 原生 Session/Cookie 路径是默认。显式无状态入口通过 `RequestGuard` 或注册的扩展 Guard 接入。Laravel 自带 `TokenGuard` 是配置的 API token 校验，JWT Bearer 由扩展显式启用。Fortify 登录与双因素流程接到对应 Guard 时独立验收。 [Laravel SessionGuard](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Auth/SessionGuard.php) · [Laravel StartSession](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Session/Middleware/StartSession.php) · [固定认证文档](https://github.com/laravel/docs/blob/960eedf0911155ad16326ade49c0ea5d18eda0b8/authentication.md)

## Gate 与 Policy

- 装配时由 `Gate::define` 登记命名能力，`Gate::policy<T>` 以资源类型登记 `Policy<T>`。应用策略在 `app/policies/` 显式注册，对应 Laravel 的约定发现与显式映射。Rust Policy 接收 `Option<&T>`，覆盖类级能力和实例能力。额外参数经 `Argument` 传递，绑定阶段验证类型。
- 运行时 Gate 使用当前 Guard 解析出的用户。`for_user` 产生指定用户的作用域视图。全局 `before` 可给出决定或继续，随后解析 Policy 或命名能力。只有 Policy 存在对应能力时才执行 Policy 的 `before`。`after` 在未形成决定时可补充结果。访客能力须显式允许，未匹配或无决定默认拒绝。
- `inspect` 返回完整 `Response`，`allows` 返回布尔结果，`authorize` 将拒绝转换为 `AuthorizationError::Denied`。评估失败保留为 `Evaluation`，避免把故障当成普通拒绝。目标响应方法为 `allow`、`deny`、`deny_with_status`、`deny_as_not_found`，并保留消息、代码和可选状态。聚合检查 `check`、`any`、`none` 随运行逻辑填充。 [Laravel Gate](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Auth/Access/Gate.php) · [固定授权文档](https://github.com/laravel/docs/blob/960eedf0911155ad16326ade49c0ea5d18eda0b8/authorization.md) · [Goravel Gate 契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/auth/access/gate.go)

## 填充与验收顺序

1. 先接通用户身份、Hashing 和两个 UserProvider，再实现请求内 Guard 解析及配置。
2. 在 Session、Cookie 和 CSRF 契约就绪后接通 `web`，验证登录轮换、退出、remember、并发请求隔离和字符串主键。
3. 实现 Gate 注册与授权判定，覆盖访客、命名能力、类型策略、before/after、拒绝状态和请求内 Guard 切换。通过实际入口验收后填写三语正文。
