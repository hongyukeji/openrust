# 邮件与通知骨架

以 Laravel 为准、参考 Goravel 实现，按职责提取 `openrust-v0.x` 的实现与测试。当前已声明公开类型与 trait，并预留文件。驱动、渠道和队列执行随功能簇实现。核对日期为 2026 年 11 月 10 日。 [固定 Laravel 基线](../plans/laravel-rebuild-baseline.md) · [Goravel v1.18.0 邮件契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/mail/mail.go)

## openrust-v0.x 复用核对

只读核对本地 `openrust-v0.x` 工作树的 `v0.x` 提交 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。下列路径相对该版本的 `vendor/openrust/framework/`。测试为源码核对，未在本批执行旧版 SMTP 或数据库测试。

| 旧版源码与测试 | 可提取的实现或验收用例 | 迁入边界 |
|---|---|---|
| `src/mail/mod.rs`、`src/config/mailer.rs`、`src/mail/log_diagnostic_tests.rs` | Lettre 异步 SMTP 适配、收件地址和 MIME 消息提交、配置诊断脱敏、Fake 邮件捕获、Mailpit 验收、无 SMTP 凭据时 log 启动 | 仅复用传输内部代码。配置改接 `mail.default` 和 `mail.mailers`。旧版 loopback/STARTTLS 策略先逐项对照 Laravel 的方案和配置。 |
| `src/mail/template.rs`、`tests/server/mail/templates.rs` | 本地化主题和正文、HTML 转义、缺变量失败、纯文本与 HTML 的 multipart、附件组合和真实 SMTP 用例 | 接入统一 Translator、视图和 `Envelope` / `Content` / `Attachment`。旧模板目录和独立语言回退机制不进入公开契约。 |
| `src/notifications.rs`、`tests/server/queue/notifications.rs` | 分渠道任务载荷、Worker 解析服务、事务回滚、渠道隔离、重试和 SMTP 接收用例 | 旧 `Notifier` 将邮件和短信直接拆成队列任务。提取分派和测试思路，按 `Notification::via`、ChannelManager 与 `ShouldQueue` 接入。旧数据库事务直写与唯一键用例需按当前队列契约重新判断。 |
| 同上 | 邮件通知可复用地址和消息适配 | 已核对的旧通知实现没有 Laravel 风格的数据库通知存储。数据库渠道按当前 Eloquent 关系和迁移补齐。 |

迁入时重新核对依赖、许可证和最低 Rust 版本。以当前入口验证行为，旧公开类型、环境变量和队列载荷不作为兼容目标。

## 目录与公开导入

框架源码位于 `vendor/openrust/framework/src/`，下表导入以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 命名邮件器和服务装配 | `mail::{MailManager, Mailer, MailServiceProvider, PendingMail}`、`contracts::mail::{Factory, Mailer}` | `mail/`、`contracts/mail/` |
| 邮件定义、组成和结果 | `mail::{Mailable, Message, SentMessage, MailError, MailFuture, MailResult}`、`mail::mailables::{Address, Envelope, Content, Attachment, Headers}` | `mail/mailable.rs`、`contracts/mail/mailable.rs`、`mail/mailables/` |
| 传输 | `mail::transport::{Transport, SmtpTransport, LogTransport}` | `mail/transport/` |
| 邮件队列 | `contracts::mail::MailQueue`、`mail::SendQueuedMailable` | `contracts/mail/mail_queue.rs`、`mail/send_queued_mailable.rs` |
| 通知、收件人和分派 | `notifications::{Notification, Notifiable, NotificationRoute, ChannelManager, NotificationSender, NotificationServiceProvider, NotificationError, NotificationFuture, NotificationResult}`、`contracts::notifications::{Factory, Dispatcher}` | `notifications/`、`contracts/notifications/` |
| 渠道、消息和持久化 | `notifications::channels::{Channel, ChannelResponse, MailChannel, DatabaseChannel}`、`notifications::messages::{MailDelivery, MailMessage, DatabaseMessage}`、`notifications::DatabaseNotification` | `notifications/{channels,messages}/`、`notifications/database_notification.rs` |
| 通知队列 | `notifications::SendQueuedNotifications` | `notifications/send_queued_notifications.rs` |

应用邮件归 `app/mail/`，通知归 `app/notifications/`。现有 `make:mail`、`make:notification` 和 `make:notifications-table` 沿用 Artisan 生成器契约。 [Artisan 骨架](artisan.md)

## MailManager、Mailer 与 SMTP

- 配置归 [config/mail.rs](../../../config/mail.rs)。`Factory::mailer(name)` 解析命名邮件器，省略名称时使用 `mail.default`。固定基线为 `MAIL_MAILER` 默认 `log`。配置采用 `mail.mailers.<name>`，通过 `transport` 选择驱动，公共地址默认值归 `mail.from`。
- `Mailable` 声明信封、内容、附件、头部、语言和命名邮件器。Rust 通过 trait 与组合表达 Laravel 的邮件类。Mailer 把定义交给渲染与 MIME 组装，再调用传输接口。计划用 `PendingMail` 接收 `to`、`cc`、`bcc` 和语言设置。模板与字段语言复用统一 Translator。 [Laravel Mailable](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Mail/Mailable.php) · [国际化骨架](localization.md)
- SMTP 目标配置包含 `MAIL_URL`、`MAIL_SCHEME`、主机、端口、凭据、超时与 EHLO 域名。端口默认 2525，未指定 scheme 时 465 对应 `smtps`，其余对应 `smtp`。连接与发送错误保留阶段和原因，凭据和邮件内容不进入诊断。传输使用 Rust 客户端适配，公开契约不依赖客户端类型。
- `log` 驱动独立于 SMTP 凭据。目标行为按 Laravel 在所选日志通道以 debug 级别写入邮件内容。旧版默认只记录接收事件，其脱敏断言用于启动和发送失败诊断。 [Laravel MailManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Mail/MailManager.php) · [Laravel LogTransport](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Mail/Transport/LogTransport.php) · [邮件配置](https://github.com/laravel/framework/blob/v13.40.0/config/mail.php)

## Notification 与渠道

`Notification::via` 为每个 Notifiable 选择渠道。ChannelManager 用 `Factory::channel` 解析已注册渠道，默认查找名称为 `mail`。通知实际选用的渠道来自 `via` 或 `send_now` 显式列表。语言依次取通知指定值、发送器指定值和收件人偏好，均缺省时沿用当前翻译作用域。通知发送前后事件接入共享 Dispatcher。 [Laravel ChannelManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Notifications/ChannelManager.php) · [NotificationSender](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Notifications/NotificationSender.php)

| 渠道 | 目标契约 |
|---|---|
| `mail` | `to_mail` 返回 `MailMessage` 或自定义 `Mailable`。普通消息的目标地址由 Notifiable 路由，邮件走已有 MailManager。自定义邮件沿用其收件人和命名邮件器。 |
| `database` | 通过收件人的 Eloquent 通知关系写入 `notifications` 表，记录 UUID、通知类型、关联模型键、结构化数据、`read_at` 和时间戳。`to_database` 优先，缺省时使用 `to_array`。类型和初始已读时间允许按上游覆盖。 |

数据库通知与邮件独立。模型关联按主键类型保留，读取和标记已读归 `DatabaseNotification`。 [Laravel MailChannel](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Notifications/Channels/MailChannel.php) · [DatabaseChannel](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Notifications/Channels/DatabaseChannel.php) · [Eloquent 骨架](eloquent.md)

## 队列接线

- Mailer 的 `send` 依据邮件队列标记选择直接发送或入队，`send_now` 强制当前调用发送。`MailQueue::queue` / `later` 使用 `SendQueuedMailable` 载荷，经 QueueManager 解析连接、队列和延迟。Worker 重建邮件并调用立即发送路径。
- ChannelManager 直接发送普通通知。标记 `ShouldQueue` 后，按每个收件人与每个渠道生成一个 `SendQueuedNotifications` 任务。支持每渠道连接、队列和延迟，Worker 用指定渠道调用 `send_now`。入队成功只表示任务已交接，渠道执行结果由 Worker 和失败记录报告。
- 邮件与通知沿用 QueueManager 的连接级提交后策略及任务覆盖。提交后入队使用稳定载荷，外层事务回滚时丢弃待入队任务。重试、退避与终态失败复用 Worker。SMTP 等外部投递在结果未知时可能重复，验收保留这个边界。 [Laravel SendQueuedMailable](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Mail/SendQueuedMailable.php) · [SendQueuedNotifications](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Notifications/SendQueuedNotifications.php) · [队列骨架](queue-scheduling.md) · [事件骨架](events.md)

## 填充与验收顺序

1. 接通邮件器选择、邮件组成和 log，适配旧版 SMTP 与 Fake，用 Mailpit 验收无凭据启动、SMTP 配置错误、邮件内容与附件。
2. 接通 MailChannel 和 DatabaseChannel，验收收件人路由、语言、持久化与通知事件。
3. 接通队列任务和提交后分派，验证立即发送、队列拆分、回滚、Worker 重试与失败记录。功能验收后填写三语正文。
