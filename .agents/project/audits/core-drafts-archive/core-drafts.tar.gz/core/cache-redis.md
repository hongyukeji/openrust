# 缓存与 Redis 骨架

以 Laravel 为准、参考 Goravel 实现。当前已声明公开类型和 trait，并预留文件。驱动、Redis I/O 和锁运行逻辑随功能簇实现。核对日期为 2026 年 11 月 10 日。 [固定 Laravel 基线](../plans/laravel-rebuild-baseline.md) · [Laravel Cache](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Cache) · [Goravel v1.18.0 Cache 契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/cache/cache.go)

## 目录与公开导入

源码位于 `vendor/openrust/framework/src/`。下表导入以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 缓存配置与命名仓储 | `cache::{CacheManager, CacheServiceProvider, Repository}`、`contracts::cache::{Factory, Repository}` | `cache/`、`contracts/cache/` |
| 驱动与数据 | `contracts::cache::Store`、`cache::{Ttl, Value, CacheError, CacheResult, CacheFuture}` | `contracts/cache/store.rs`、`cache/mod.rs` |
| 驱动类型 | `cache::{ArrayStore, DatabaseStore, DynamoDbStore, FailoverStore, FileStore, MemcachedStore, NullStore, RedisStore, SessionStore, StorageStore}` | `cache/*_store.rs` |
| 原子锁 | `contracts::cache::{Lock, LockProvider}`、`cache::{Lock, ArrayLock, DatabaseLock, DynamoDbLock, FileLock, MemcachedLock, RedisLock}` | `contracts/cache/`、`cache/*lock.rs` |
| Redis 连接装配 | `redis::{RedisManager, RedisServiceProvider}`、`contracts::redis::Factory` | `redis/`、`contracts/redis/` |
| 命令、订阅与返回值 | `redis::connections::{Connection, Subscription}`、`contracts::redis::Connection`、`redis::{Value, RedisError, RedisFuture, RedisResult}` | `redis/connections/`、`redis/mod.rs` |

## CacheManager、Repository 与 Store

- 配置归 [config/cache.rs](../../../config/cache.rs)，保留 `cache.default`、`cache.stores.<name>` 与 `cache.prefix`。`CACHE_STORE` 未设置时以 `database` 为默认。CacheManager 按名称解析并复用仓储，目标方法 `extend` 登记驱动工厂。每个仓储封装一个 Store，统一处理键、TTL 和命中语义。
- `Repository` 已声明 `get`、`put`、`add`、`touch`、`pull`、`forget`、`increment`、`decrement` 和 `forever`。`remember`、`remember_forever` 随具体 Repository 填充，加载回调失败时不写入。`pull` 沿用取值后删除语义，`remember` 沿用读不到才执行回调的语义，二者不隐式取得锁。
- Store 只接收已归一化的正整数秒或显式 `forever` 操作。`put` 与 `add` 省略 TTL 时以永久写入为目标。绝对过期时间按上游向上取整为秒。TTL 为零、负数或已过期时，`put` 和 `touch` 删除旧值，`add` 返回 false。区分未命中、空值和后端错误，Repository 的 `has` 按 Laravel 将 null 视为未命中。有限 TTL 的 `add` 优先使用驱动的原子写入能力，上游的通用回退不提供原子保证。
- 数据库 Store 使用配置表、连接和独立锁表入口，表由既有 `make:cache-table` 契约提供。Redis Store 使用命名连接。文件 Store 默认目录为 `storage/framework/cache/data/`。其余驱动保留各自职责，平台专属 APC、Octane 能力随对应组件处理。标签、请求内 memo 和限流在各功能簇验收。
- 键前缀用于命名隔离。按 Laravel，`flush` 的范围由 Store 决定，Redis Store 会清空所选 Redis 库，不能用键前缀推断清理范围。数据库或 Redis 锁存储与缓存数据分开配置时，分别验证清理行为。 [Laravel CacheManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Cache/CacheManager.php) · [Repository](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Cache/Repository.php) · [缓存配置](https://github.com/laravel/framework/blob/v13.40.0/config/cache.php)

## RedisManager

`database.redis` 配置归 [config/database.rs](../../../config/database.rs)。`RedisManager` 按名称解析连接，省略名称使用 `default`。单实例基线的 `default` 与 `cache` 分别默认使用数据库 0 和 1。缓存 Redis Store 默认从 `REDIS_CACHE_CONNECTION` 选择数据连接，默认 `cache`，并从 `REDIS_CACHE_LOCK_CONNECTION` 选择锁连接，默认 `default`。

`Connection::command` 接收命令名和二进制参数，返回保留协议类型的 Redis Value。`subscribe`、`psubscribe` 使用独立订阅连接。RedisManager 复用已解析的连接，目标方法 `purge` 清除命名连接，`extend` 登记连接工厂。池、原生客户端适配及集群连接留给 Redis 组件实现，框架接口独立于客户端库。自动重试须区分连接失败与写入结果未知，诊断过滤连接凭据和敏感参数。 [Laravel RedisManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Redis/RedisManager.php) · [Redis 配置](https://github.com/laravel/framework/blob/v13.40.0/config/database.php) · [固定 Redis 文档](https://github.com/laravel/docs/blob/960eedf0911155ad16326ade49c0ea5d18eda0b8/redis.md)

## 原子锁与 Session

- Store 通过 `lock_provider` 声明锁能力。`LockProvider::lock` 创建锁，`restore_lock` 用已知 owner 恢复句柄。Lock 声明单次尝试 `get`、限时等待 `block`、`owner`、`refresh`、`release` 和 `force_release`。等待超时使用 `CacheError::LockTimeout`。锁租期独立于等待上限。一般锁省略租期时沿用各后端行为，Session 总是传入有限租期。
- Redis 锁使用原子条件写入取得所有权。续期与释放都要原子比较 owner，避免过期持有者释放后继请求的锁。显式 `force_release` 无条件释放。回调和 Session 路径使用作用域清理，异常和取消要验证清理行为，有限租期处理进程退出。内存锁只覆盖其共享存储范围，多进程或多实例的 Session 锁须使用共享后端。
- `StartSession` 在 `session.block` 或路由 `block` 启用时，从 `session.block_store` 选命名 Cache Store，未指定时走默认 Cache Store。它与 Session 数据驱动、Session 的缓存 Store 独立配置。锁键为 `session:<ID>`。路由可指定租期和等待上限，应用回退值均为 10 秒，Session 重试间隔按上游 50 毫秒。
- `StartSession` 先取得锁，再加载 Store、执行请求并保存 Session，完成后释放。等待超时不进入业务处理。Cookie Session 不支持 blocking，缺少锁能力时返回明确错误。响应仍按既定 Cookie 和 Session 回程顺序处理。 [Laravel Lock](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Cache/Lock.php) · [RedisLock](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Cache/RedisLock.php) · [StartSession](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Session/Middleware/StartSession.php) · [Session 骨架](session-cookie-csrf.md)

## 填充与验收顺序

1. 接通 CacheManager、Repository 和默认数据库 Store，验收命中、永久值、过期、计数和失败语义。
2. 接通 RedisManager、Redis Store 和原子锁，实测命名连接、二进制数据、锁竞争、过期、恢复、续期和旧 owner 释放。
3. 接通 Session blocking，用并发请求验收锁内加载和保存、超时、取消以及后端故障。功能验收后填写三语正文。
