# 分页与 API Resources 骨架

以固定 Laravel Framework v13.40.0 的分页查询、游标及资源响应为准。固定 Goravel v1.18.0 用于参考 Query 与 ORM 共用分页职责，其 `Paginate` 采用 count 加 offset/limit。三类分页器、资源转换和 JSON 契约按 Laravel。 [Laravel 分页](https://laravel.com/docs/13.x/pagination) · [Laravel API Resources](https://laravel.com/docs/13.x/eloquent-resources) · [固定 Goravel Query](https://github.com/goravel/framework/blob/a554ced468cada50a269780692a0491e5f9e3a11/database/db/query.go#L684-L697)

## openrust-v0.x 复用核对

已只读检查 `openrust-v0.x` 的 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`，以下路径相对旧版 `vendor/openrust/framework/`。

| 旧版路径 | 实现阶段可提取部分 |
| --- | --- |
| `src/database/query/builder.rs` | 提取 `paginate`／`simple_paginate` 的 count 副本、查询窗口、请求页码和边界检查，按新 Query/Eloquent 接口重接。 |
| `src/http/response.rs`、`tests/http/resource.rs` | 复用偏移溢出、默认页码及真实 HTTP 响应检查的用例。旧 `Paginated<T>` 包装及其状态约定不作为新主线的默认 JSON 契约。 |
| SeaORM 依赖的 paginator | 可查阅数据库层的用法。旧框架树中未找到可直接迁入的 Laravel 游标分页器、`JsonResource` 或 `ResourceCollection`。资源路由注册和资源序列化是各自独立的功能。 |

## 目录与公开接口

以下 `src/` 路径相对 `vendor/openrust/framework/`。本批声明类型、扩展 trait 与查询选项，具体查询、导航及序列化逻辑留待实现。

| 职责 | 公开导入 | 文件 |
| --- | --- | --- |
| 分页器与查询选项 | `openrust::pagination::{Paginator, LengthAwarePaginator, CursorPaginator, Cursor, PageOptions, CursorOptions}` | `src/pagination/` |
| 分页器扩展契约 | `openrust::contracts::pagination::{Paginator, LengthAwarePaginator, CursorPaginator}` | `src/contracts/pagination/mod.rs` |
| 资源转换与响应 | `openrust::http::resources::json::{JsonResource, ResourceCollection, ResourceItems, ResourceResponse, PaginatedResourceResponse, PaginationLinks, PaginationInformation}` | `src/http/resources/json/` |
| 应用资源与生成器 | `app::http::resources`、`artisan make:resource` | [app/http/resources/mod.rs](../../../app/http/resources/mod.rs)、现有 `src/foundation/console/resource_make_command.rs` |

## 查询构造器与 Eloquent

| Builder 入口 | 分页器 | 目标行为 |
| --- | --- | --- |
| `paginate(PageOptions, total)` | `LengthAwarePaginator<T>` | 统计总数并按页执行 offset/limit，允许显式总数省略 count。总数为零时跳过行查询。count 查询对 group、having、union 及别名按上游规则处理。 |
| `simplePaginate(PageOptions)` | `Paginator<T>` | 读取 `perPage + 1` 行判断是否还有下一页，不执行 count。 |
| `cursorPaginate(CursorOptions)` | `CursorPaginator<T>` | 基于排序列进行键集查询，读取 `perPage + 1` 行。向前或向后遍历时按上游应用比较方向和结果顺序。 |

- Query Builder 返回 `DatabaseResult` 中的 `Row` 分页器，默认每页 15 条。Eloquent Builder 返回 `Model` 实例的分页器，使用模型默认页容量，并保留已有作用域、模型水合及预加载。默认参数名为 `page` 或 `cursor`，显式选项优先于当前请求解析；无请求时使用框架默认。页码回退与偏移溢出分别验证，超出最后一页时保留请求页码和空结果。
- 游标按排序列保存值和 `_pointsToNextItems`，使用无填充的 Base64 URL-safe JSON。缺少游标或编码无法解析时按固定 resolver 处理。有效游标必须能提供排序列所需值；排序须稳定，排序列或组合应唯一且非空。Query 要求有排序，Eloquent 无排序时沿用主键回退。游标不提供总条数或页码。 [固定 Query Builder](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Database/Query/Builder.php) · [固定 Cursor](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Pagination/Cursor.php) · [数据库骨架](database.md) · [Eloquent 骨架](eloquent.md)

## 分页导航与 JSON

- `url`、`previousPageUrl`、`nextPageUrl` 共用 URL 编码和请求路径。通过 `appends`、`withQueryString`、`fragment` 控制查询参数和片段；生成时由分页器提供本页码或游标值，调用方的同名参数不覆盖它。缺失前后链接用 `None`，JSON 序列化为 `null`。总量分页额外提供 `total`、`lastPage` 和范围链接；HTML `links`／`render` 走视图工厂。
- 直接序列化分页器时沿用各自的 Laravel 字段。总量分页含 `total`、`last_page` 和页码链接数组；简单分页含 `current_page_url`，不提供总量字段；游标分页含 `next_cursor` 和 `prev_cursor`。三者直接输出的结构与资源集合包装分别验收。 [URL 骨架](url-generation.md) · [视图骨架](views-templates.md)

## JsonResource 与 ResourceCollection

- `JsonResource::toArray(&Request)` 将模型或其他应用数据投影为 JSON。资源解析保留字段遗漏与显式 `null` 的差异，`whenLoaded` 仅使用已加载关系，避免序列化触发查询。Eloquent 的 `toResource`、`toResourceCollection` 预留显式类型或注册映射，替代 PHP 的动态类查找。预定 `with`、`additional`、`withResponse` 和包装设置，按上游处理附加数据及响应定制。
- `ResourceCollection` 接收普通集合或任一分页器，只转换行数据，保留原分页状态。 `preserveQuery` 追加当前请求查询串，`withQuery` 追加指定参数。分页资源即使关闭普通包装仍有 `data` 容器，默认顶层输出 `data`、`links`、`meta`。
- 顶层 `links` 固定取 `first`、`last`、`prev`、`next`，不可用时为 `null`。`meta` 由分页器输出排除 `data` 和四个导航 URL 后组成，因此总量分页的页码链接数组仍在 `meta.links`，游标分页保留游标元数据。集合可通过 `paginationInformation` 覆盖默认信息，按固定用例核对与 `with`、`additional` 的合并。 [固定 PaginatedResourceResponse](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Http/Resources/Json/PaginatedResourceResponse.php) · [固定 ResourceCollection](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Http/Resources/Json/ResourceCollection.php)

## 填充与验收顺序

1. 接入两种 offset 分页，验证 count、副本、空页、溢出、默认值和链接。再接游标，验证组合排序、双向导航及边界。日常数据库行为用 MySQL 8.4 验收。
2. 接入资源转换和 Eloquent 已加载关系，用固定资源测试覆盖省略字段、查询串保留、三类分页结构、包装及附加数据。
3. 用实际 HTTP 验证响应状态和 JSON `links`／`meta`，通过后填写三语 Pagination 和 API Resources 正文。
