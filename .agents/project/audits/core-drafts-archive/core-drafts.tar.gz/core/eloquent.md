# Eloquent ORM 骨架

当前阶段已声明公开类型和 trait，并预留对应文件。下文的目标方法随功能簇实现。核对日期为 2026 年 11 月 10 日。命名和可观察行为以[固定 Laravel 基线](../plans/laravel-rebuild-baseline.md)为准。Goravel 用于参考显式注册、类型化上下文和关系加载。 [Laravel Eloquent 源码](https://github.com/laravel/framework/tree/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Database/Eloquent) · [Goravel v1.18.0 ORM 契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/database/orm/orm.go)

## 目录与公开导入

框架源码位于 `vendor/openrust/framework/src/`。应用模型继续放在 `app/models/`，由 `app/models/mod.rs` 接入应用。以下 Rust 导入均以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 模型、元数据与实例状态 | `database::eloquent::{Model, ModelMetadata, ModelState, Attributes}` | `database/eloquent/{model,mod}.rs` |
| 模型查询、集合和作用域 | `database::eloquent::{Builder, Collection, Scope}` | `database/eloquent/{builder,collection,scope}.rs` |
| 关系和中间表 | `database::eloquent::relations::{Relation, BelongsTo, BelongsToMany, HasOne, HasMany, HasOneThrough, HasManyThrough, MorphOne, MorphMany, MorphTo, MorphToMany, Pivot, MorphPivot}` | `database/eloquent/relations/` |
| 访问器与修改器 | `database::eloquent::casts::Attribute` | `database/eloquent/casts/attribute.rs` |
| 自定义属性转换 | `contracts::database::eloquent::{Castable, CastsAttributes, CastsInboundAttributes}` | `contracts/database/eloquent/` |
| 事件与监听器 | `database::eloquent::concerns::{ModelEvent, ModelEventListener, ModelEventResponse}` | `database/eloquent/concerns/has_events.rs` |

关系、属性、批量赋值、时间戳、全局作用域及软删除分别预留职责文件。Laravel 的 Eloquent Builder 接口是 IDE 标记，Rust 用有实际类型参数的具体 `Builder` 表达模型约束。 [Laravel Builder 契约](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Contracts/Database/Eloquent/Builder.php)

## Model

Rust 应用模型通过组合 `ModelState` 并实现 `Model`，对应 PHP 模型继承。声明的接口为 `metadata() -> &'static ModelMetadata`、`from_state(ModelState) -> Self`、`state(&self) -> &ModelState`、`state_mut(&mut self) -> &mut ModelState`。元数据由应用显式登记，默认行为随 Model 实现统一提供。

- **元数据。** 默认表名为模型名称的复数 snake_case，主键为 `id`，默认自增整数，默认管理 `created_at`、`updated_at`。允许显式覆盖表名、主键类型、连接和时间戳设置。复数规则用固定上游用例验收。
- **状态。** 记录当前原始属性、原始快照、最近一次保存的变更、持久化状态和已加载关系。水合按数据库返回列构建实例并同步原始快照，随后触发 `retrieved`。`fill` / `create` 按 `fillable` 和 `guarded` 处理批量赋值。缺失属性、SQL NULL、关系未加载和关系查无记录分别表达。
- **持久化。** 目标签名为 `async fn save(&mut self, connection: &mut dyn ConnectionInterface) -> DatabaseResult<bool>`，`delete` 同形但返回 `DatabaseResult<Option<bool>>`，以 `None` 表达未持久化模型无需删除。连接由模型元数据或显式事务上下文提供，SQL 失败走错误结果，事件取消返回 `false`。更新与删除使用模型主键，主键修改时以原始主键定位已保存行。保留 `get_original`、`get_dirty`、`get_changes` 与 `was_changed` 的不同含义。 [Laravel Model](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Eloquent/Model.php)

## Eloquent 查询构造器

`Builder<'connection, M: Model>` 复用 `database::query::Builder<'connection>`，查询计划、绑定和方言仍归数据库层。Eloquent 处理模型水合、作用域和关系。`Model::query(connection: &mut dyn ConnectionInterface) -> Builder<'_, Self>` 是计划入口。普通请求按模型解析连接，事务内使用借入的同一逻辑连接。

| 操作 | 目标契约 |
|---|---|
| 读取与水合 | 异步 `get(&mut self, columns: Option<&[&str]>) -> DatabaseResult<Collection<M>>`。同参数的 `first` 和另接收主键 `&Value` 的 `find` 返回 `DatabaseResult<Option<M>>`。`first_or_fail`、`find_or_fail` 区分模型不存在和驱动执行失败。 |
| 作用域 | `Scope<M>::apply` 修改当前模型查询。保留全局作用域、局部作用域和按名称移除作用域。软删除由 `SoftDeletes` 和 `SoftDeletingScope` 负责，默认排除已软删除行。 |
| 关系查询 | `with` 批量预加载，支持嵌套路径及约束。`has`、`where_has`、`with_count` 基于同一关系定义产生约束。 |
| 写入 | `create` 和按实例持久化的入口走模型赋值、时间戳及事件生命周期。查询级批量 `update`、`delete` 返回影响行数，按上游规则不为每一行水合模型或触发实例事件。 |

Rust 通过显式调用访问模型字段和作用域。SQL 构造方法与底层 Query Builder 保持一致。 [Laravel Eloquent Builder](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Eloquent/Builder.php) · [关系查询](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Eloquent/Concerns/QueriesRelationships.php)

## 模型关系

`Relation::get_results` 接收连接并异步返回关联结果。具体关系类型已预留，关系的键和默认约定由模型元数据与关系声明共同决定。Rust 使用显式关系方法及预加载名称注册表，代替 PHP 动态属性和方法发现。预加载按键批量读取，再将结果回填到对应模型。

| 关系类型 | 目标结果与行为 |
|---|---|
| `BelongsTo<P, R>`、`HasOne<P, R>`、`HasOneThrough<P, I, R>` | `Option<R>`。保留外键、所有者键、局部键、通过模型与 `with_default` 的适用语义。 |
| `HasMany<P, R>`、`HasManyThrough<P, I, R>` | `Collection<R>`。同一父键的多条记录归入同一集合。 |
| `BelongsToMany<P, R>` | `Collection<R>` 加中间表数据。保留 `with_pivot`、`with_timestamps`、`attach`、`detach`、`sync` 的职责。 |
| `MorphOne<P, R>`、`MorphMany<P, R>`、`MorphToMany<P, R>` | 类型列与 ID 列共同约束。分别返回单条或集合，多对多关联使用 `MorphPivot`，反向入口 `morphed_by_many` 也返回 `MorphToMany`。 |
| `MorphTo<P>` | 由注册的 morph map 解析目标模型，按目标类型分组预加载。结果包含目标类型信息，异构结果的具体 Rust 表示随多态实现定稿。 |

同一连接的关系操作继续使用当前事务句柄。指定不同连接的关系按其显式连接解析，跨数据库关系的查询限制以固定上游行为验收。 [Laravel 关系类型](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Database/Eloquent/Relations)

## 属性转换

- `casts::Attribute` 对应访问器、修改器或两者，计划提供 `make`、`get`、`set`。模型通过元数据登记对应属性。保持原始数据库值、读取结果和写入值的边界，缓存与回写行为随访问器验收。
- `CastsAttributes<M>` 具有业务值关联类型。读取将原始 `database::Value` 转为业务值，写入返回属性映射，单列转换也使用该形式。`CastsInboundAttributes<M>` 只处理写入。`Castable<M>` 让业务类型声明自己的 caster。
- 内置转换按上游核对整数、布尔值、精确小数、日期时间、JSON、枚举、加密和哈希的适用语义。内置 cast 保留上游对 NULL 的处理，自定义 cast 是否接收 NULL 单独验收。批量赋值的授权检查先于属性赋值。序列化的可见性和追加属性随序列化能力实现。 [Laravel 属性转换契约](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Contracts/Database/Eloquent) · [HasAttributes](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Eloquent/Concerns/HasAttributes.php)

## 生命周期事件

沿用上游事件键 `eloquent.<event>: <模型限定名>`，`forceDeleting` 和 `forceDeleted` 保留原大小写。Rust 模型限定名由模型类型确定。模型监听器和 Observer 走框架事件分发，支持显式注册及自定义事件映射。异步监听器可借用当前操作连接，无连接操作使用 `None`。

| 场景 | 触发约定 |
|---|---|
| 水合 | `retrieved` 在实例状态初始化后触发。 |
| 新建与更新 | `saving` → `creating` / `updating` → `created` / `updated` → `saved`。无变更的已有模型仍触发 `saving` / `saved`。 |
| 删除与恢复 | 保留 `deleting` / `deleted`、`trashed`、`restoring` / `restored`、`forceDeleting` / `forceDeleted`。软删除恢复经过保存流程。 |
| 复制 | `replicating` 对新实例分派。 |

可中止的事件中，`Continue` 继续监听，`Stop` 停止后续监听但允许操作，`Cancel` 取消操作。非中止式通知保持正常分派。Quietly 和 `without_events` 的抑制限于当前操作作用域。普通后置事件与提交后 Observer 分别处理。提交后 Observer 在无事务时立即执行，有事务时等待最外层成功提交，回滚时丢弃。 [Laravel HasEvents](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Database/Eloquent/Concerns/HasEvents.php) · [Goravel 事件上下文](https://github.com/goravel/framework/blob/v1.18.0/contracts/database/orm/events.go)

## 填充与验收顺序

1. 在[数据库连接与 Query Builder](database.md)就绪后接通 Model 元数据、水合、属性状态与基本查询。
2. 实现转换、批量赋值和事件，再验收实例新增、更新、删除及软删除，覆盖拒绝写入、回滚、批量操作和无变更保存。
3. 实现基础关系和预加载，再填充中间表、通过关系和多态，核对结果归属、查询次数、键覆盖和事务连接。
4. 功能验收后填写三语 Eloquent 正文。Factory、分页、序列化和 API Resource 按各自契约推进。
