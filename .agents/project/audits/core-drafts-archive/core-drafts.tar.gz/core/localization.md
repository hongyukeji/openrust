# 国际化骨架

以 Laravel 为准、参考 Goravel 实现。已声明公开类型和 trait，预留文件与数据库来源的目录。词条加载、查询和接线随功能簇实现。核对日期为 2026 年 11 月 10 日。 [固定 Laravel 基线](../plans/laravel-rebuild-baseline.md) · [Laravel Translator](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Translation/Translator.php) · [Goravel v1.18.0 翻译契约](https://github.com/goravel/framework/tree/v1.18.0/contracts/translation)

## 目录与公开导入

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 翻译和加载接口 | `openrust::contracts::translation::{Translator, Loader}` | `vendor/openrust/framework/src/contracts/translation/` |
| 运行类型 | `openrust::translation::{Translator, FileLoader, MessageSelector, TranslationServiceProvider}` | `vendor/openrust/framework/src/translation/` |
| 词条和加载结果 | `openrust::translation::{Line, Lines, TranslationError, TranslationFuture, TranslationResult}` | `vendor/openrust/framework/src/translation/mod.rs` |
| 数据库来源扩展 | 计划为 `openrust_translation_database::DatabaseLoader` | `vendor/openrust/translation-database/src/` |

数据库扩展已预留源码入口，Cargo 包和数据库依赖随该扩展实现接入。应用词条位于根目录 `lang/`，框架内置词条归框架包的 `lang/`。两者使用相同键结构。

## 接口与作用域

- `Loader::load(locale, group, namespace)` 异步返回 `TranslationResult<Lines>`。缺少一组词条返回空结果，读取、连接或解析失败返回错误。`Line` 表示文本或嵌套分组，文件和数据库统一产出此结构。
- 沿用验证层已声明的 `Translator::get`、`choice`、`get_locale` 和 `set_locale`，补充分组词条查询 `array`。`choice` 按有效语言做复数选择，`get` 和 `array` 处理参数替换。Laravel 的文本和分组可以从同一个动态方法返回，Rust 用独立方法表达类型差异。
- `TranslationServiceProvider` 装配 Loader 和 Translator。Loader 可共享，语言选择和 Translator 视图限定在请求或命令作用域。目标准备入口为 `async fn prepare(&mut self, locales: &[&str]) -> TranslationResult<()>`，加载已注册词条组，默认准备当前语言及回退语言。HTTP 入口在验证和渲染前准备快照。显式查询其他语言前先准备该语言。同步 `get`、`choice`、`array` 从快照读取，使规则验证与错误渲染无需阻塞式数据库查询。

## 文件与数据库来源

| 来源 | 目标契约 |
|---|---|
| 文件 | 默认启用。`FileLoader` 支持 `lang/<locale>/<group>.json` 的分组词条和 `lang/<locale>.json` 的原文键。分组采用 Goravel 的 JSON 格式表达 Laravel 分组数据。 |
| 扩展词条 | 保留 `namespace::group.key`。FileLoader 的目标登记入口为 `add_namespace`、`add_json_path`、`namespaces`。扩展原始词条可由应用 `lang/vendor/<namespace>/<locale>/<group>.json` 覆盖。 |
| 数据库 | 显式安装并启用 `DatabaseLoader`。按语言、命名空间、分组和键查词条，使用配置连接并复用数据库层。仅覆盖同语言、同命名空间、同组的同名文件词条。来源缺失时继续查文件，来源故障独立记录并按配置的文件降级策略处理。 |

文件合并遵循 Laravel 的路径优先级，应用词条覆盖框架内置词条。词条路径按已注册目录解析，校验语言、分组和命名空间以防止越界读取。数据库扩展只提供来源，消息替换、复数和回退继续由 Translator 统一处理。 [Laravel FileLoader](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Translation/FileLoader.php) · [Goravel FileLoader](https://github.com/goravel/framework/blob/v1.18.0/translation/file_loader.go)

## 默认语言与回退

- 应用配置为 `app.locale` 和 `app.fallback_locale`，分别读取 `APP_LOCALE` 与 `APP_FALLBACK_LOCALE`，默认均为 `en`。未指定语言时使用应用默认语言，请求或命令可在自己的作用域选择语言，单次查询可显式传入语言。 [Laravel 应用配置](https://github.com/laravel/framework/blob/v13.40.0/config/app.php)
- 常规 `get` 先查有效语言的 JSON 原文键，随后查同语言的分组词条，再查回退语言的分组词条。缺失时返回请求键并应用相应替换。复数查询按固定上游确定有效语言，测试覆盖 JSON 原文键、分组键和缺失键的差异。
- 回退按语言逐步进行。当前语言文件中已有词条时，回退语言的数据库词条不会覆盖它。缓存按语言、命名空间和分组隔离，切换请求语言不改变其他请求的默认值。 [Laravel Translator 查找机制](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Translation/Translator.php) · [固定本地化文档](https://github.com/laravel/docs/blob/960eedf0911155ad16326ade49c0ea5d18eda0b8/localization.md)

## 验证与 Artisan 接线

- **验证。** Factory 注入同一请求的 Translator。分组和文本查询覆盖 `validation.custom`、`validation.attributes`、`validation.values` 与规则消息。参数替换、异常摘要和字段消息使用同一语言。Web 将生成的消息写入错误包，API 422 保留 `message` 和 `errors` 结构。 [验证与 FormRequest 骨架](validation.md)
- **Artisan。** Console Kernel 使用相同语言配置和 Translator 契约，在输出帮助或解析错误前准备文件词条。`list`、`help` 和参数错误走轻量入口，即使启用数据库来源也能使用文件目录独立完成。翻译命令说明、帮助、提示和面向人的解析错误。命令名、选项、别名、退出码与机器可读输出结构保持稳定。 [Artisan 骨架](artisan.md) · [Artisan 交互本地化待办](../todo.md)

## 填充与验收顺序

1. 接通语言配置、文件 Loader、文本和分组查找。用英、简、繁覆盖默认语言、显式语言、回退、缺键、参数与复数。
2. 实现数据库扩展，验证同语言覆盖、故障策略、命名空间隔离和并发请求隔离。
3. 验收 API 与 Web 验证消息，再覆盖 Artisan 的列表、帮助与非法参数，并实测轻量命令在 HTTP 和数据库均未启动时可运行。
