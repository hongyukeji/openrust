# Artisan 内核与生成器

根应用装配命令后调用框架 `Application::handleCommand`。该入口执行 Console Kernel 的处理和终止流程，并写出命令输出。已验收应用引导、`list`、文本帮助、命令占位和编程式调用。下文也保留后续目标，包括结构化帮助、全局选项、命令发现和生成器。核对日期为 2026 年 11 月 10 日。

基线为 [Laravel Framework v13.40.0](https://github.com/laravel/framework/tree/1449bf241017087fbd38c118ecaabef3f6797fdc)、[Laravel 应用骨架 v13.11.0](https://github.com/laravel/laravel/tree/06d016a364a37430eec9cbc52209adce3d7667ce)。`list`、`help` 和名称解析由 Symfony Console 提供，描述器以 Laravel 依赖范围内的 [Symfony Console v7.4.0](https://github.com/symfony/console/tree/v7.4.0) 固定对照。编译型语言的入口和注册方式参考 [Goravel v1.18.0](https://github.com/goravel/framework/tree/a554ced468cada50a269780692a0491e5f9e3a11)。

## 内核和注册

| 职责 | 公开路径 | 文件（相对框架 crate） |
|---|---|---|
| Artisan 生命周期契约 | `openrust::contracts::console::Kernel` | `src/contracts/console.rs` |
| 引导应用、分派和终止 | `openrust::foundation::console::Kernel` | `src/foundation/console/mod.rs` |
| 命令注册表和名称解析 | `openrust::console::Application` | `src/console/application.rs` |
| 命令定义和异步处理 | `openrust::console::{Command, CommandDefinition}` | `src/console/command.rs` |
| 已解析输入、输出和错误 | `openrust::console::{Input, Output, ConsoleError}` | `src/console/mod.rs` |
| 生成器目标路径和模板契约 | `openrust::console::GeneratorCommand` | `src/console/generator_command.rs` |
| 内置命令描述 | 通过命令行的 `list`、`help` 使用 | `src/console/{list_command,help_command}.rs` |
| 待实现的框架命令目录 | `console::Application::register_planned_commands` | `src/console/planned.rs` |
| 命令生成器和基础模板 | `make:command` | `src/foundation/console/console_make_command.rs`、`src/foundation/console/stubs/console.rs.stub` |

- `./artisan`、Windows 的 `artisan.bat` 和发布二进制的 `<应用> artisan` 汇入同一个内核。内核接收去掉二进制及模式名的原始参数，按应用根目录引导配置、容器和 Provider。执行结束后把原始参数及状态交给终止钩子。编程式 `call` 使用同一命令定义，未传入输出对象时捕获输出供 `output` 读取。`queue` 随队列契约定稿。 [Laravel Console Kernel](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Console/Kernel.php)
- 框架和扩展通过各自的 Provider 提供内置命令。应用命令在 `app/console/commands/` 下编译，通过 `ApplicationBuilder::withCommands` 声明注册函数。闭包命令写在 `routes/console.rs`，通过 `withRouting` 的 `commands` 声明注册函数。两类函数均接受框架 `console::Application` 的可变引用，并在 Console Kernel 引导后运行。Rust 的模块由编译器静态纳入，生成应用命令时要同步接入模块和注册清单。 [Laravel ApplicationBuilder](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Configuration/ApplicationBuilder.php) · [Goravel 命令契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/console/command.go)
- Provider、应用命令和闭包命令最终走同一个注册表入口，目标方法为 `Application::add_command(&mut self, command: Box<dyn Command>) -> Result<(), ConsoleError>`。命令定义保存规范名称、别名、描述、帮助、位置参数顺序、选项值类型、短选项、默认值及可见性。分派、列表和帮助共享此定义。注册顺序固定，重复名称或别名按上游注册表的覆盖顺序解析。应用启动、展示帮助和读取定义可以使用元数据，业务依赖等到实际执行才解析。 [Laravel Console Application](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Console/Application.php) · [Symfony 命令注册与名称解析](https://github.com/symfony/console/blob/v7.4.0/Application.php)
- 冒号分隔命令组。`make:model` 的规范名是完整字符串，`make` 是分组。解析优先精确名称和别名，唯一缩写可解析，歧义或未知名称报错。完整列表使用规范名称，按分组排序，别名可在其所属命名空间内查找。Laravel 和 Goravel 同名命令共用一条定义。

## list 和 help

| 入口 | 位置参数 | 命令选项及行为 |
|---|---|---|
| `artisan` / `artisan list` | `[namespace]`，默认全部 | `--raw` 平铺文本，`--format=txt\|json\|xml\|md` 默认 `txt`，`--short` 缩减描述器输出中的命令明细 |
| `artisan help` | `[command_name]`，默认 `help` | `--raw` 输出纯文本帮助，`--format=txt\|json\|xml\|md` 默认 `txt` |
| `artisan <命令> --help` / `-h` | 取目标命令的定义 | 与 `artisan help <命令>` 使用同一描述器。用法统一写作 `Usage: artisan …` |

按上游描述器验证排序、别名和机器可读输出的结构。JSON、XML 的 `--short` 保留别名用法，省略完整定义。全局选项按基线接入，包括 `-q/--quiet`、`--silent`、`-v/-vv/-vvv`、`-V/--version`、`--ansi/--no-ansi`、`-n/--no-interaction`、`--env[=名称]` 和 `-h/--help`。

列表和帮助成功为 0，命令正常完成时返回自己的退出码。按 Laravel 内核捕获异常的路径，未知名称、歧义、参数解析异常和命令执行异常报告错误并返回 1。切换到框架内核后，Clap 参数错误已从 2 改为 1。骨架阶段保留 `Planned` 状态，查看占位帮助可成功，执行占位返回 1 并说明尚未实现。 [ListCommand](https://github.com/symfony/console/blob/v7.4.0/Command/ListCommand.php) · [HelpCommand](https://github.com/symfony/console/blob/v7.4.0/Command/HelpCommand.php) · [描述器](https://github.com/symfony/console/tree/v7.4.0/Descriptor) · [Laravel Console Kernel](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Console/Kernel.php)

当前注册表允许同名命令替换，跨命令的别名冲突会返回注册错误。命令行使用 Clap 的唯一前缀解析。按命名空间分段缩写和 Laravel 的别名覆盖顺序仍待对应验收。HTTP 监听配置由 HTTP 入口校验，应用骨架的命令列表和帮助在 HTTP 端口被占用、数据库端口无服务时已实测通过。

## make:* 生成规则

表中路径相对应用根目录。类型名使用 PascalCase，Rust 文件和模块使用 snake_case。例如 `Admin/UserController` 写入 `app/http/controllers/admin/user_controller.rs`，类型为 `UserController`。生成后要接入相应的 `mod.rs` 或注册清单，确保代码被编译和使用。嵌套名称支持目录分隔符及上游的命名空间写法，写入前检查无效标识符、路径穿越、符号链接逃逸和归一化后的重名。`make:migration --path --realpath` 是显式指定绝对路径的入口。

模板随命令所在组件放在 `console/stubs/` 下，应用自定义模板放在根目录 `stubs/`，按上游支持的命令和模板名优先查找。Rust 模板命名为 `*.rs.stub`，例如 `console.rs.stub`。模板选择和主文件目标路径由 `GeneratorCommand` 声明。迁移生成器归数据库组件，复用同一个迁移创建器和时间戳格式。注册、追加产物和覆盖规则按各命令核对。先检查冲突和目标路径，覆盖只用于该命令允许覆盖的文件。

41 个命令的源码文件已按上游组件预留。例如 `make:controller` 对应 `src/routing/console/controller_make_command.rs`，`make:migration` 对应 `src/database/console/migrations/migrate_make_command.rs`。其余文件分别归 `foundation`、`cache`、`database`、`notifications`、`queue`、`routing`、`session`、`ai`、`validation` 的 `console/`。命令在各组件就绪后接入 Rust 模块树和注册表。

### Laravel 基线命令（37 个）

`<name>` 为必填位置参数，有上游交互提示的命令在允许交互时可提示补齐。没有参数的表迁移命令以「无」标识。`[=值]` 表示选项可不带值，`=值` 表示选项出现时必须给值。`T` 表示支持生成配套测试的 `--test`、`--pest`、`--phpunit`。配套测试归 `tests/feature/`，`--test` 使用 Rust 测试入口。Pest、PHPUnit 的选项名保留在上游差异清单中，Rust 模式应明确报告工具不适用。

| 命令 | 参数 | 专属选项（含短名） | 默认产物及派生行为 |
|---|---|---|---|
| `make:cache-table` | 无 | 无 | `database/migrations/<时间戳>_create_cache_table.rs`。别名 `cache:table` |
| `make:cast` | `<name>` | `-f/--force`、`--inbound` | `app/casts/<name>.rs`。可选只写入转换 |
| `make:channel` | `<name>` | `-f/--force` | `app/broadcasting/<name>.rs` |
| `make:class` | `<name>` | `-i/--invokable`、`-f/--force` | `app/<name>.rs`。Rust 的单方法类型提供显式调用方法 |
| `make:command` | `<name>` | `-f/--force`、`--command[=命令名]`、T | `app/console/commands/<name>.rs`。默认签名 `app:<kebab-case 类型名>` |
| `make:component` | `<name>` | `--inline`、`--view`、`--path=目录`、`-f/--force`、T | `app/view/components/<name>.rs` 和 `resources/views/components/<name>.html`。`--inline` 只生成类型，`--view` 只生成视图，`--path` 改视图目录 |
| `make:config` | `<name>` | `-f/--force` | `config/<name>.rs` 并接入配置模块。别名 `config:make` |
| `make:controller` | `<name>` | `--api`、`--type=模板`、`--force`、`-i/--invokable`、`-m/--model[=模型]`、`-p/--parent[=模型]`、`-r/--resource`、`-R/--requests`、`-s/--singleton`、`--creatable`、T | `app/http/controllers/<name>.rs`。资源、API、嵌套、单例模板依选项选择。`--api` 排除 `create`、`edit`。适用时生成 Store/Update 请求 |
| `make:enum` | `<name>` | `-s/--string`、`-i/--int`、`-f/--force` | `app/<name>.rs`。默认普通枚举，可指定字符串映射或整数表示 |
| `make:event` | `<name>` | `-f/--force` | `app/events/<name>.rs` |
| `make:exception` | `<name>` | `-f/--force`、`--render`、`--report` | `app/exceptions/<name>.rs`。按选项生成渲染或上报钩子 |
| `make:factory` | `<name>` | `-m/--model[=模型]` | `database/factories/<name>.rs` |
| `make:interface` | `<name>` | `-f/--force` | `app/<name>.rs`，Rust 类型为 trait |
| `make:job` | `<name>` | `-f/--force`、`--sync`、`--batched`、T | `app/jobs/<name>.rs`。默认队列任务，按选项选同步或批处理模板 |
| `make:job-middleware` | `<name>` | `-f/--force`、T | `app/jobs/middleware/<name>.rs` |
| `make:listener` | `<name>` | `-e/--event[=事件]`、`-f/--force`、`--queued`、T | `app/listeners/<name>.rs`。可生成带事件类型的监听器或队列监听器 |
| `make:mail` | `<name>` | `-f/--force`、`-m/--markdown[=视图]`、`--view[=视图]`、T | `app/mail/<name>.rs`。视图选项另生成 `resources/views/` 下对应模板，默认视图名 `mail.<名称>` |
| `make:middleware` | `<name>` | T | `app/http/middleware/<name>.rs` |
| `make:migration` | `<name>` | `--create[=表]`、`--table[=表]`、`--path[=目录]`、`--realpath`、`--fullpath`（上游已弃用） | `database/migrations/<时间戳>_<name>.rs`。依据选项或名称选建表、改表或通用模板 |
| `make:model` | `<name>` | `-a/--all`、`-c/--controller`、`-f/--factory`、`--force`、`-m/--migration`、`--morph-pivot`、`--policy`、`-s/--seed`、`-p/--pivot`、`-r/--resource`、`--api`、`-R/--requests`、T | `app/models/<name>.rs`，无模型目录时用 `app/`。`--all` 联动工厂、迁移、Seeder、Policy、资源控制器及请求 |
| `make:notification` | `<name>` | `-f/--force`、`-m/--markdown[=视图]`、T | `app/notifications/<name>.rs`，可生成 Markdown 邮件模板 |
| `make:notifications-table` | 无 | 无 | `database/migrations/<时间戳>_create_notifications_table.rs`。别名 `notifications:table` |
| `make:observer` | `<name>` | `-f/--force`、`-m/--model[=模型]` | `app/observers/<name>.rs` |
| `make:policy` | `<name>` | `-f/--force`、`-m/--model[=模型]`、`-g/--guard[=守卫]` | `app/policies/<name>.rs` |
| `make:provider` | `<name>` | `-f/--force` | `app/providers/<name>.rs`，同步登记 `bootstrap/providers.rs` |
| `make:queue-batches-table` | 无 | 无 | `database/migrations/`，批次表默认 `job_batches`，可随配置变更。别名 `queue:batches-table` |
| `make:queue-failed-table` | 无 | 无 | `database/migrations/`，失败任务表默认 `failed_jobs`，可随配置变更。别名 `queue:failed-table` |
| `make:queue-table` | 无 | 无 | `database/migrations/`，任务表默认 `jobs`，可随配置变更。别名 `queue:table` |
| `make:request` | `<name>` | `-f/--force` | `app/http/requests/<name>.rs` |
| `make:resource` | `<name>` | `-f/--force`、`-j/--json-api`、`-c/--collection` | `app/http/resources/<name>.rs`。`--collection` 或 `Collection` 名称后缀选择集合模板，可选 JSON:API 模板 |
| `make:rule` | `<name>` | `-f/--force`、`-i/--implicit` | `app/rules/<name>.rs` |
| `make:scope` | `<name>` | `-f/--force` | `app/models/scopes/<name>.rs`，无模型目录时用 `app/scopes/` |
| `make:seeder` | `<name>` | 无 | `database/seeders/<name>.rs` |
| `make:session-table` | 无 | 无 | `database/migrations/<时间戳>_create_sessions_table.rs`。别名 `session:table` |
| `make:test` | `<name>` | `-f/--force`、`-u/--unit`、`--pest`、`--phpunit` | 默认 `tests/feature/<name>.rs`，单元测试归 `tests/unit/`。接入所属测试入口 |
| `make:trait` | `<name>` | `-f/--force` | `app/<name>.rs`，模板对应 Rust trait，职责仍为可复用行为 |
| `make:view` | `<name>` | `--extension[=扩展名]`、`-f/--force`、T | `resources/views/<name>.<扩展名>`，点号可表示子目录。默认扩展名拟沿用当前应用的 `html`，上游默认 `blade.php`。配套测试归 `tests/feature/view/` |

上游对照 [GeneratorCommand](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Console/GeneratorCommand.php)、[配套测试选项](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Console/Concerns/CreatesMatchingTest.php)、[Foundation 生成器](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Foundation/Console)、[路由生成器](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Routing/Console)、[数据库生成器](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Database/Console)及[表迁移基类](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Console/MigrationGeneratorCommand.php)。

### Goravel 独有命令（4 个）

| 命令 | 参数 | 专属选项 | 默认产物 |
|---|---|---|---|
| `make:agent` | `<name>` | `-f/--force` | `app/ai/agents/<name>.rs` |
| `make:filter` | `<name>` | `-f/--force` | `app/filters/<name>.rs`，登记到验证过滤器配置 |
| `make:package` | `<组织>/<包名>` | `-r/--root=目录` | `vendor/<组织>/<包名>/`，包含 `Cargo.toml`、`README.md`、`src/lib.rs` 和 Provider 骨架。Goravel 默认 `packages/`，OpenRust 按仓库的 vendor 布局指定所有者 |
| `make:tool` | `<name>` | `-f/--force` | `app/ai/tools/<name>.rs` |

同名命令的参数和选项仍按 Laravel。独有命令参照 Goravel 的 [AI 命令](https://github.com/goravel/framework/tree/v1.18.0/ai/console)、[过滤器生成器](https://github.com/goravel/framework/blob/v1.18.0/validation/console/filter_make_command.go)和[包生成器](https://github.com/goravel/framework/blob/v1.18.0/foundation/console/package_make_command.go)。

## 填充与验收顺序

1. 先接通框架命令注册、内核和应用入口，再接 `list`、`help`，用同一命令定义验证精确名称、别名、缩写、歧义、格式输出、流向和退出码。
2. 实现路径和模板生成，先用 `make:command` 验证「生成、编译、注册、可列出、可执行」闭环。再按组件填充其他生成器。数据库、HTTP、视图、队列、AI 等模板随相应组件的真实接口验收。
3. 在临时应用目录验收缺参和非交互、嵌套名称、默认与自定义模板、重复运行、覆盖保护和多产物选项。根脚本、Windows 入口和发布二进制通过同一套命令用例。
