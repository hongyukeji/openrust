# 文件存储骨架

以 Laravel 为准、参考 Goravel 实现，按职责提取 `openrust-v0.x` 的实现和测试。当前已声明公开类型与 trait，并预留文件。磁盘、HTTP 与 Artisan 的执行逻辑随功能簇实现。核对日期为 2026 年 11 月 10 日。 [固定 Laravel 基线](../plans/laravel-rebuild-baseline.md) · [Goravel v1.18.0 存储契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/filesystem/storage.go)

## openrust-v0.x 复用核对

只读核对本地 `openrust-v0.x` 工作树的 `v0.x` 提交 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。下列路径相对该版本的 `vendor/openrust/framework/`。本轮仅核对旧测试源码。

| 旧版源码与测试 | 可提取的实现或用例 | 迁入边界 |
|---|---|---|
| `src/filesystem.rs` 中的 `FilesystemManager`、`StorageDriver`、`StoragePath` | 命名磁盘解析和缓存、自定义驱动、配置错误诊断、绝对路径和穿越拒绝测试 | 按当前容器与 `filesystems` 配置接入。保留 Laravel 的磁盘和相对路径契约。 |
| 同文件的本地后端、`publish_local`、`put_stream` 及单元测试 | 有界流和背压、同磁盘暂存发布、取消后保留旧目标、拒绝符号链接逃逸、可见性与目录权限验证 | 提取已验证的内部路径和发布边界。依当前应用根与磁盘根解析。Windows 与 Unix 权限差异单独验收。 |
| 同文件的 `S3Driver`、`OpenDalBackend` 及 `tests/server/storage/s3.rs` | S3-compatible 连接、分段上传取消、ACL、版本绑定签名下载及 Copy 结果未知后的清理用例 | 对照 Laravel 的 S3 配置和能力，复查 OpenDAL 与 AWS SDK 的许可证、Rust 最低版本和必要范围。ACL 已启用和已禁用用例分开。 |
| `src/filesystem/README.md` 与流式上传下载代码 | HTTP 流转换、调用方授权、元数据头和文件名校验 | 接入现有 Request、Response、FormRequest 和 Gate。旧 `storage.*` 配置、`fs` 驱动名及旧上传类型不作为兼容目标。 |

## 目录与公开导入

源码位于 `vendor/openrust/framework/src/`。下表导入均以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 命名磁盘与服务装配 | `filesystem::{FilesystemManager, FilesystemServiceProvider}`、`contracts::filesystem::Factory` | `filesystem/`、`contracts/filesystem/factory.rs` |
| 磁盘契约与应用适配器 | `contracts::filesystem::{Filesystem, Cloud, FileStream}`、`filesystem::FilesystemAdapter` | `contracts/filesystem/`、`filesystem/filesystem_adapter.rs` |
| 本地与 S3 | `filesystem::{LocalFilesystemAdapter, AwsS3V3Adapter}` | `filesystem/{local_filesystem_adapter,aws_s3_v3_adapter}.rs` |
| 写入参数与临时上传 URL | `filesystem::{Visibility, WriteOptions, TemporaryUploadUrl, FilesystemError, FilesystemFuture, FilesystemResult}` | `filesystem/mod.rs` |
| 上传对象与本地签名访问 | `http::UploadedFile`、`filesystem::{ServeFile, ReceiveFile}` | `http/uploaded_file.rs`、`filesystem/{serve_file,receive_file}.rs` |
| Artisan 链接管理 | `storage:link`、`storage:unlink` | `foundation/console/{storage_link_command,storage_unlink_command}.rs` |

Facade 计划接入 `openrust::support::facades::Storage`，复用同一 Factory。 [Laravel Filesystem 契约](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Contracts/Filesystem)

## 磁盘配置与适配器

- 配置归 [config/filesystems.rs](../../../config/filesystems.rs)，保留 `filesystems.default`、`filesystems.disks.<name>` 和 `filesystems.links`。未设置 `FILESYSTEM_DISK` 时使用 `local`。`Factory::disk` 按名称异步解析并返回共享的 FilesystemAdapter。Manager 复用命名磁盘，预定 `build` 构造临时磁盘，`extend` 登记驱动，`forget_disk` / `purge` 清除缓存的解析结果。
- FilesystemAdapter 统一路径、选项、结果和可见性。磁盘接口声明存在性、读写、流式操作、复制、移动、目录与元数据。相对路径按当前磁盘根解析，拒绝越界；`path` 对本地返回根下路径，对远端返回磁盘限定的对象键。底层保留错误原因。适配器按上游对 `throw` 和 `report` 的处理决定传播错误、报告或返回 `false` / `None`，配置和路径错误可区分。

| 磁盘 | 目标契约 |
|---|---|
| `local` | 驱动为 `local`，根为 `storage/app/private`。配置 `serve` 时接入签名的临时下载和上传路由。 |
| `public` | 同样使用 `local` 驱动，根为 `storage/app/public`，默认可见性为 public，URL 基址为 `APP_URL/storage`。通过公开链接提供访问。 |
| `s3` | 接入 bucket、region、凭据、endpoint、自定义 URL 和 path-style 配置。提供对象 URL 及临时下载、上传 URL，上传签名结果包含必需请求头。对象可见性、ACL 和 bucket policy 分别验收。 |

临时 URL 是独立能力。FilesystemAdapter 的目标方法 `temporary_url` 与 `temporary_upload_url` 接收相对路径、绝对到期时间及签名选项，分别返回 URL 与 `TemporaryUploadUrl`。磁盘可公开生成 URL 时仍可能无权读取对象。S3 签名可用性要按 endpoint 与实际访问方网络验证，远端发布结果未知时保留独立错误。 [Laravel 文件存储配置](https://github.com/laravel/framework/blob/v13.40.0/config/filesystems.php) · [FilesystemManager](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Filesystem/FilesystemManager.php) · [AwsS3V3Adapter](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Filesystem/AwsS3V3Adapter.php)

## HTTP 上传与下载

- HTTP multipart 解析产生 `UploadedFile`，客户端文件名和媒体类型保留为原始元数据。FormRequest 校验大小、类型和规则后，业务授权决定磁盘和目标路径。`UploadedFile::store`、`store_as` 以及公开可见性变体是目标入口，委托磁盘的 `put_file` / `put_file_as`。
- `put_file` 生成对象名，`put_file_as` 使用经过校验的应用指定名称，两者流式写入并返回相对路径。保留直接流式写入，受控传输验证大小、背压、取消和临时数据清理。客户端文件名不直接充当磁盘路径。
- FilesystemAdapter 的目标 `response` 与 `download` 通过 `read_stream` 生成 HTTP Response，分别使用 inline 与 attachment。私有文件先授权再读取，或通过适用的签名路由访问。响应头由框架安全构造，文件内容分块发送。缺文件、拒绝与存储故障交由 HTTP 层分别渲染。 [Laravel UploadedFile](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Http/UploadedFile.php) · [Laravel FilesystemAdapter](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Filesystem/FilesystemAdapter.php) · [验证与 FormRequest 骨架](validation.md) · [认证与授权骨架](auth.md)

## storage:link 与部署接线

- `artisan storage:link` 读取 `filesystems.links`，默认建立 `public/storage` 指向 `storage/app/public`。默认按应用根解析绝对目标，`--relative` 从链接所在目录计算相对目标，便于发布目录整体搬移。
- `--force` 只重建已有链接，保留普通文件和真实目录。断链可按上游规则重建。配套 `storage:unlink` 只移除配置登记的链接。链接目标与命令工作目录的区别由实际调用验收。
- 静态文件服务只从公开目录进入，允许已配置的公开存储链接。私有磁盘的下载和签名路由独立处理。平台差异按实际链接能力验收，包括 Windows 和相对链接。两个命令当前仍为 Artisan 占位。 [Laravel StorageLinkCommand](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Console/StorageLinkCommand.php) · [StorageUnlinkCommand](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Console/StorageUnlinkCommand.php) · [Artisan 骨架](artisan.md)

## 填充与验收顺序

1. 实现磁盘解析和 local/public，验证配置、路径、流式读写、取消、可见性和失败语义。
2. 接通 HTTP 上传下载和链接命令，验证私有授权、签名、响应头、公开链接和发布目录搬移。
3. 接入 S3，在隔离的 S3-compatible 环境验收 endpoint、流式上传和签名。涉及 ACL 或服务商策略的用例按对应服务实际验收。功能验收后填写三语正文。
