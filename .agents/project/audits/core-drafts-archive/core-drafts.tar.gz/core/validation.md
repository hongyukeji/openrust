# 表单验证与 FormRequest 骨架

已声明公开类型和 trait，并预留对应文件。规则执行、请求解析和响应渲染随功能簇实现。核对日期为 2026 年 11 月 10 日。行为以[固定 Laravel 基线](../plans/laravel-rebuild-baseline.md)为准，Rust 的显式输入、规则注册和请求上下文参考 Goravel v1.18.0。 [Laravel 验证源码](https://github.com/laravel/framework/tree/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Validation) · [Goravel 验证契约](https://github.com/goravel/framework/blob/v1.18.0/contracts/validation/validation.go)

## 目录与公开导入

框架源码位于 `vendor/openrust/framework/src/`。下表导入以 `openrust::` 开头。

| 职责 | 公开导入 | 源文件 |
|---|---|---|
| 工厂、验证器及注册 | `validation::{Factory, Validator, ValidationServiceProvider}`、`contracts::validation::{Factory, Validator}` | `validation/`、`contracts/validation/` |
| 规则定义、执行与上下文 | `validation::{Rule, RuleSet, RuleContext, RuleFailure, Data, Value}`、`contracts::validation::ValidationRule` | `validation/{rule,mod}.rs`、`contracts/validation/validation_rule.rs` |
| 内置流式规则 | `validation::rules::{Email, Enum, Exists, File, In, Password, Unique}` | `validation/rules/` |
| 验证结果与异常 | `validation::{ValidatedInput, ValidationException, ValidationError, ValidationResult, ValidationFuture}` | `validation/{validated_input,validation_exception,mod}.rs` |
| 表单请求与装配 | `foundation::http::{FormRequest, FormRequestError}`、`foundation::providers::FormRequestServiceProvider` | `foundation/http/form_request.rs`、`foundation/providers/` |
| Web 错误包 | `support::{MessageBag, ViewErrorBag}`、`view::middleware::ShareErrorsFromSession` | `support/`、`view/middleware/` |
| 验证消息翻译 | `contracts::translation::Translator` | `contracts/translation/translator.rs`、`validation/concerns/formats_messages.rs` |

应用表单请求放在 `app/http/requests/`，应用规则放在 `app/rules/`。HTTP 异常渲染预留 `foundation/exceptions/handler.rs`，由框架统一处理。 [Laravel 验证契约](https://github.com/laravel/framework/tree/v13.40.0/src/Illuminate/Contracts/Validation)

## Validator 与 Rule

- `Factory::make(data, rules, messages, attributes)` 接收一次验证的输入、规则和消息覆盖。Factory 按请求取得翻译上下文。注册目标入口保留 `extend`、`extend_implicit`、`replacer`。输入保留嵌套结构及上传文件，并区分字段缺失与显式 null。
- `Validator::validate` 返回 `ValidatedInput` 或 `ValidationError::Invalid(ValidationException)`。`fails` 返回验证是否失败，`errors` 提供 `MessageBag`。`validated`、`safe` 读取该次验证产物。后端故障通过 `Execution` 传播。规则名、参数和错误消息保持可定位，并按 Laravel 支持点路径、通配符、`bail`、全局首错停止、`sometimes` 和 `after`。
- `validation::Rule` 负责创建流式规则。`ValidationRule::validate(context, attribute, value)` 异步返回零条或多条 `RuleFailure`，对应 Laravel 的 `$fail` 回调。隐式规则可对缺失值运行。Rust 通过 `RuleContext` 访问完整输入和请求作用域服务，覆盖需要 DataAware 或 ValidatorAware 信息的用法。
- `exists` 和 `unique` 通过数据库层的 presence verifier 访问配置连接。规则失败与查询执行故障分别处理。`unique` 的忽略主键取可信模型或已授权记录。 [Laravel Validator](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Validation/Validator.php) · [Laravel Rule](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Validation/Rule.php) · [Laravel ValidationRule](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Contracts/Validation/ValidationRule.php)

## FormRequest

应用类型实现 `FormRequest`，由 `FormRequestServiceProvider` 接入控制器参数解析。Rust 使用显式类型注册和请求解析，代替 PHP 容器的动态反射。

1. 解析一次 HTTP 输入，调用 `prepare_for_validation` 处理输入。
2. 调用 `authorize`，可使用当前请求的 Guard、Gate 和路由绑定。缺省授权通过，普通授权拒绝走 403；自定义授权响应沿用其状态。拒绝时不继续执行规则。
3. 取得验证数据及 `rules`、`messages`、`attributes`，构造 Validator 并运行规则和后置验证钩子。未知字段拒绝默认关闭，可显式启用。
4. 验证失败抛给统一 HTTP 渲染。成功后调用 `passed_validation`，处理器通过 `validated` 或 `safe` 取得经验证数据。额外输入不会自动出现在验证产物中，嵌套数组键的保留遵循上游规则。

`FormRequestError` 区分授权失败与验证阶段失败。扩展钩子及自定义 Validator 随运行时装配实现。 [Laravel FormRequest](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Http/FormRequest.php) · [Laravel 解析生命周期](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Validation/ValidatesWhenResolvedTrait.php) · [认证与授权骨架](auth.md)

## API 422 与 Web 错误回传

`ValidationException` 的目标契约保留字段错误、消息摘要、状态码、命名错误包、重定向目标和可选自定义响应。默认状态为 422，错误包为 `default`。由异常处理器统一渲染，自定义响应优先。

| 请求路径 | 目标行为 |
|---|---|
| JSON/API | 按 `expectsJson` 或应用的 JSON 渲染策略返回 HTTP 422。JSON 包含 `message` 和 `errors`，每个字段的值为消息数组，嵌套字段使用点路径。API 组可显式采用 JSON 策略。此路径无需 Session。 |
| Web | 重定向到配置的目标，否则回上一页。将 `ViewErrorBag` 闪存到 Session 的 `errors`，可按请求或 FormRequest 选择命名包。将允许回填的输入闪存到 `_old_input`。默认排除 `current_password`、`password`、`password_confirmation`，并保留应用扩展排除清单。 |
| Web 下一次请求 | `ShareErrorsFromSession` 在 `StartSession` 之后提供视图错误包，无错误时使用空包。错误与旧输入依闪存生命周期自动过期。 |

Web 的异常渲染在 Session 保存前完成，使错误包与旧输入能在同一响应回程持久化。授权拒绝和基础设施错误继续走各自的异常处理路径。 [Laravel 异常处理器](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Foundation/Exceptions/Handler.php) · [Laravel ValidationException](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Validation/ValidationException.php) · [Session 回程契约](session-cookie-csrf.md)

## 国际化消息

- Factory 注入统一的 `Translator`，验证器使用当前请求语言。未指定语言时使用应用默认 `app.locale`，缺少译文时使用 `app.fallback_locale`。语言选择限定在请求作用域，后端翻译来源由统一翻译层装配。
- 消息选择按 Laravel 优先使用本次验证的字段或规则覆盖，再匹配 `validation.custom` 和规则默认消息。显示名取本次 `attributes` 或 `validation.attributes`，值标签取 `validation.values`。支持点路径、通配符和 `:attribute`、`:min` 等参数替换。
- JSON 摘要和字段错误使用同一语言。摘要按上游以首条消息加本地化的其余错误计数生成，空错误列表使用本地化的默认摘要。Web 闪存已生成的消息。文件词条以 `lang/<locale>/` 为入口，数据库来源可接入同一翻译层，验证器只依赖翻译契约。 [Laravel 消息格式化](https://github.com/laravel/framework/blob/v13.40.0/src/Illuminate/Validation/Concerns/FormatsMessages.php) · [Goravel Translator](https://github.com/goravel/framework/blob/v1.18.0/contracts/translation/translator.go)

## 填充与验收顺序

1. 实现输入、规则和 Validator，先核对嵌套字段、通配符、缺失与 null、首错停止和验证产物。
2. 接入统一翻译和 FormRequest，验证准备、授权、规则执行、成功钩子的顺序，以及默认语言和回退。
3. 验证真实 API 422 JSON、Web 重定向及下一请求的错误包与旧输入、敏感字段过滤。功能验收后填写三语正文。
