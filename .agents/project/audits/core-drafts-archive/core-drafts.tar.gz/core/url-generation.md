# URL 生成、重定向与签名链接骨架

以固定 Laravel Framework v13.40.0 的命名路由、签名和重定向契约为准。固定 Goravel v1.18.0 用于参考编译型应用的路由装配和 HTTP 重定向响应接口，签名使用 Laravel 机制。 [Laravel URL 生成](https://laravel.com/docs/13.x/urls) · [Goravel HTTP Response](https://github.com/goravel/framework/blob/a554ced468cada50a269780692a0491e5f9e3a11/contracts/http/response.go)

## openrust-v0.x 复用核对

已只读检查 `openrust-v0.x` 的 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。以下路径相对旧版 `vendor/openrust/framework/`。

| 旧版路径 | 实现阶段可提取部分 |
| --- | --- |
| `src/routing/url_generator.rs`、`src/http/request/url_query.rs` | 提取命名路由的参数替换、原始查询串处理、签名和应用级密钥解析。按当前路由集合、可信请求来源和 URL 配置重新接线。 |
| `tests/fixtures/laravel_signed_url.json`、`tests/http/router/signed_url.rs` | 移植固定 PHP 夹具和真实 HTTP 用例，覆盖过期、相对／绝对地址、查询串顺序、忽略项、密钥轮换与无效签名提前拒绝。 |
| `src/routing/redirector.rs`、`tests/http/router/action_redirect.rs` | 提取 `Location` 与状态码验证、`back`／`guest`／`intended` 的 Session 边界、请求绑定和表单错误回传用例。旧接口名和动态兼容层按当前契约取舍。 |

## 目录与公开接口

下表源码相对 `vendor/openrust/framework/src/`。本轮只声明类型和 trait，具体方法与运行接线留待实现。

| 职责 | 公开路径 | 文件 |
| --- | --- | --- |
| URL 生成与路由替换 | `openrust::routing::{UrlGenerator, RouteUrlGenerator}`、`openrust::contracts::routing::UrlGenerator` | `routing/{url_generator,route_url_generator}.rs`、`contracts/routing/url_generator.rs` |
| 参数、签名和错误 | `openrust::routing::{RouteParameter, RouteParameters, UrlValue, SignatureMode, SignatureQueryFilter, UrlError, UrlResult}` | `routing/url_generator.rs` |
| 重定向与便捷入口 | `openrust::routing::{Redirector, RedirectOptions}`、`openrust::support::facades::{URL, Redirect}` | `routing/redirector.rs`、`support/facades.rs` |
| 请求验签 | `openrust::routing::middleware::ValidateSignature` | `routing/middleware/validate_signature.rs` |

## 命名路由与普通 URL

- URL 服务绑定当前应用的路由集合和请求上下文。普通 `route` 默认生成绝对 URL，支持显式相对路径。命名查找与路由注册共用同一索引，支持域名和路径占位、可选参数、路由默认值。实现时为 `UrlRoutable` 接入 `getRouteKey` 值投影，剩余参数生成查询串。路由缺失、必填参数缺失、无效值分别报告。
- `to`、`current`、`previous`、`asset` 与 `query` 与命名路由共用生成服务。HTTP 使用经过可信代理和 Host 策略解析的请求来源；CLI、邮件和队列在无请求时使用配置的 `APP_URL`。资源地址保留 `ASSET_URL` 的独立覆盖入口。
- PHP 动态数组由保序的 `RouteParameter`／`UrlValue` 表达，支持命名、位置及嵌套参数。普通查询保留上游顺序和编码规则，签名时单独应用上游排序。 [固定 RouteUrlGenerator](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Routing/RouteUrlGenerator.php)

## 签名、过期与密钥轮换

- `signedRoute` 支持无到期时间或显式到期时间，`temporarySignedRoute` 要求到期时间。签发前拒绝用户传入保留参数 `signature`、`expires`。将到期转换为 Unix 秒，按 Laravel 排序后生成未签名 URL，用当前密钥计算 HMAC-SHA256，再附加十六进制签名。
- 默认绝对签名包含源站信息。相对签名使用路径与查询串，签发和验证必须使用同一模式。验签基于可信请求 URL 与原始查询串，剔除 `signature` 和配置的忽略项后保持其余键的原始顺序与编码。到期和签名单独验证，签名比较使用恒定时间比较，边界和多值查询按固定 PHP 夹具验收。
- 签发用 `app.key`，验签依次使用当前和 `app.previous_keys`。对应 [APP_KEY 与轮换契约](encryption-hashing.md)，但 URL 签名使用配置原值，保留 `base64:` 前缀。普通 URL 无需签名密钥。缺密钥时签发明确失败，错误不包含密钥。密钥解析属于应用，轮换回归覆盖更新后立即签发、旧链接仍有效和移除旧密钥后失效。
- `ValidateSignature` 沿用现有 HTTP Middleware trait。路由别名为 `signed`，相对模式为 `signed:relative`，预留 `absolute`、`relative` 和 `except` 装配入口。无效或过期请求在进入处理器前返回 403，交现有 Handler 协商 HTML／JSON。 [固定 UrlGenerator](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Routing/UrlGenerator.php) · [固定 ValidateSignature](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Routing/Middleware/ValidateSignature.php)

## 重定向与邮箱验证

- `Redirector` 通过同一个 UrlGenerator 支持 `to`、`route`、`signedRoute`、`temporarySignedRoute`、`secure`、`refresh`、`away` 和 `back`。无 Session 的重定向返回 `UrlResult<Response>`，默认 302。 `RedirectOptions` 预留显式状态和响应头。 `away` 交给应用明确选择外部地址，统一验证状态、`Location` 和 HTML 转义。
- `guest` 与 `intended` 复用现有 Session 存储，返回异步的 `UrlResult<Response>`。 `guest` 对匹配路由的 HTML GET 记录当前完整 URL，其余走 previous 规则。 `intended` 一次性读取并删除 `url.intended`，缺失时使用默认目标。错误回传和输入 flash 接入同一请求的 Session。 [固定 Redirector](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Routing/Redirector.php)
- `VerifyEmail` 调用 `temporarySignedRoute("verification.verify", …)`，默认 60 分钟，绑定用户主键及当前邮箱摘要。入口先经 `auth` 与 `signed`，之后 `EmailVerificationRequest` 比对登录用户及邮箱。邮箱验证路由不配置忽略 `expires`、身份或邮箱相关参数。 [密码重置与邮箱验证骨架](password-reset-email-verification.md) · [Session 骨架](session-cookie-csrf.md)

## 填充与验收顺序

1. 接入路由名索引、参数编码和请求来源，验证普通及命名 URL、域名参数、资源地址和缺失参数。
2. 接入密钥与验签，移植固定 PHP 夹具并实际发送 HTTP 请求，验证修改参数、过期、轮换、相对／绝对模式及 403。
3. 接入重定向和认证流程，验证状态与响应头、Session 消费和实际邮件链接。通过后补三语 URL Generation 正文。
