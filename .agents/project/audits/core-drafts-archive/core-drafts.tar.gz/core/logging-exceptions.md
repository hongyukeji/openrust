# 日志与异常处理骨架

以 Laravel Framework v13.40.0 为准。固定 Goravel v1.18.0 参考命名渠道、上下文传递、文件轮转和 HTTP 恢复入口。日志级别、渠道配置及异常报告与渲染顺序由固定 Laravel 源码确定。 [Laravel 日志](https://laravel.com/docs/13.x/logging) · [Laravel 异常](https://laravel.com/docs/13.x/errors) · [Goravel 日志源码](https://github.com/goravel/framework/tree/a554ced468cada50a269780692a0491e5f9e3a11/log)

## openrust-v0.x 复用核对

已只读核对 `openrust-v0.x` 提交 `6d1a81924451e15f595f68c8dfb520ad6d6c44cf`。以下是可提取的职责和用例，后续按新主线接口重新验收。

| 旧版路径 | 复用范围 |
| --- | --- |
| `vendor/openrust/framework/src/logging/{manager,sinks}.rs`、`vendor/openrust/framework/tests/unit/logging/{manager,sinks}.rs` | 提取命名渠道缓存、栈组合、紧急回退、配置变更后的重新解析及结构化转义。复用嵌套栈、循环检测和并发缓存回归。 |
| `vendor/openrust/framework/src/logging/context.rs`、`vendor/openrust/framework/tests/unit/logging/context.rs` | 提取公开与隐藏上下文隔离、渠道缓存按每条记录读取当前上下文、不同应用之间的隔离用例。 |
| `vendor/openrust/framework/src/foundation/exceptions.rs`、`tests/consumers/test-app/tests/exception_handler.rs` | 提取按类型配置报告、渲染、最终响应和内容协商的用例。 |
| `vendor/openrust/framework/tests/unit/core/error_i18n.rs`、`vendor/openrust/framework/tests/http/router.rs` | 提取生产错误脱敏、默认语言与回退、HTML 转义、HEAD、状态和协议头回归。旧状态改写、API 包装和旧配置键不迁入默认契约。 |

## 目录与公开接口

以下 `src/` 路径位于 `vendor/openrust/framework/`。本轮声明类型和 trait，保留现有异常响应接线。

| 职责 | 公开路径 | 文件 |
| --- | --- | --- |
| 命名渠道与服务装配 | `openrust::log::{LogManager, Logger, LogServiceProvider, Level, LogContext, LogError}` | `src/log/` |
| 可注入的日志接口 | `openrust::contracts::log::Logger` | `src/contracts/log/mod.rs` |
| 日志上下文和事件 | `openrust::log::context::Repository`、`openrust::log::events::MessageLogged`、`openrust::support::facades::{Log, Context}` | `src/log/{context,events}/`、`src/support/facades.rs` |
| 异常服务与配置 | `openrust::foundation::exceptions::Handler`、`openrust::contracts::debug::{ExceptionHandler, Exception}`、现有 `openrust::foundation::configuration::Exceptions` | `src/foundation/{exceptions,configuration}/`、`src/contracts/debug/` |

- 日志适配接口 `log(Level, &str, &LogContext) -> LogResult<()>` 对应 Laravel 使用的 PSR Logger。应用端 `Logger` 保留 `emergency`、`alert`、`critical`、`error`、`warning`、`notice`、`info`、`debug`，并预定 `withContext`、`withoutContext`。Rust 以枚举和结构化数据代替 PHP 动态参数。
- Handler 以 `ExceptionHandler` 的 `shouldReport`、`report`、`render`、`renderForConsole` 为边界。Rust 使用借用的 `Exception` 区分已有 `HttpError` 和普通错误。HTTP 返回现有 `Response`，Console 写入现有 `Output`，命令退出状态仍由 Console Kernel 管理。

## 日志渠道与上下文

- `LogServiceProvider` 绑定应用级 `log`，默认日志、Facade 和 Handler 共用同一个 Manager。`channel`／`driver` 解析并缓存渠道，`build` 创建临时渠道，`stack` 按顺序组合多个渠道，`extend` 注册自定义驱动。解析失败转紧急渠道并保留安全诊断。嵌套栈按各层配置处理失败，并检测配置循环。
- [config/logging.rs](../../../config/logging.rs) 保留 `logging.default`、`logging.channels`、`logging.deprecations`，默认 `LOG_CHANNEL=stack`、`LOG_STACK=single`、`LOG_LEVEL=debug`。首批预定 `stack`、`single`、`daily`、`monthly`、`stderr`、`null`、自定义和紧急渠道。应用文件使用 `storage/logs/openrust.log`，按上游保留渠道阈值、占位符替换、轮转和 `ignore_exceptions`。Slack、syslog、errorlog 和第三方处理器按固定配置单独验收。PHP Monolog 类名由 Rust 注册的等价处理器表达。
- Logger 的局部 `withContext` 与 Manager 的 `shareContext` 区分，单次调用字段覆盖同名的 Logger 上下文。Context Repository 另保存请求或任务的公开及隐藏上下文，公开字段进入日志附加数据，隐藏字段不写日志和 `MessageLogged`。上下文随请求或任务作用域清理，队列接线预定序列化与恢复边界，避免不同请求、工作任务和应用之间串值。 [固定 LogManager](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Log/LogManager.php) · [Laravel Context](https://laravel.com/docs/13.x/context) · [队列骨架](queue-scheduling.md)

## 异常报告与响应渲染

- 保留 [bootstrap/app.rs](../../../bootstrap/app.rs) 的 `withExceptions`。预定注册 `map`、`reportable`、`renderable`、`respond`、`level`、`context`、`dontReport`、`dontReportWhen`、`dontReportDuplicates`、`stopIgnoring`、`dontFlash` 和报告 `throttle`。Rust 以显式类型回调表达 PHP 的反射匹配。
- **报告。** 先做异常映射，再应用忽略、去重与限流策略。允许报告时依次处理异常自身的报告行为、匹配的应用回调、默认日志。停止默认报告遵循上游回调契约。同一异常实例的去重与相同文本的不同异常区分。报告使用配置的级别和安全上下文，并避免日志后端失败触发递归报告。 [限流骨架](rate-limiting.md)
- **渲染。** 先做异常映射，依次处理异常自带的响应、类型渲染回调及框架默认渲染，最后进入 `respond`。`shouldRenderJsonWhen` 覆盖默认 `Request::expectsJson`；根应用当前显式让 `api/*` 返回 JSON。默认 HTML 支持应用错误视图和框架回退，JSON 保留 `message` 及适用的验证错误字段。认证与验证按各自契约返回 Web 重定向或 JSON，保留 405 的 `Allow`、429 的限流响应头等协议元数据。
- **诊断边界。** `APP_DEBUG` 控制对外诊断细节。生产普通 500 使用安全消息，密码等敏感输入按 `dontFlash` 排除。可翻译消息复用统一 Translator 和默认语言回退，日志保留稳定诊断字段。HTTP Kernel 将现有 `HttpError` 渲染接入 Handler，Console Kernel 将命令错误接到 `renderForConsole`。 [固定 Handler](https://github.com/laravel/framework/blob/1449bf241017087fbd38c118ecaabef3f6797fdc/src/Illuminate/Foundation/Exceptions/Handler.php) · [验证骨架](validation.md) · [国际化骨架](localization.md)

## 填充与验收顺序

1. 接通默认渠道、栈、轮转和紧急回退，验收并发渠道解析、失败与重新解析。再接入请求及任务上下文，验证隔离和隐藏字段。
2. 接通 Handler、报告回调和统一日志。验证忽略、去重、报告限流、日志失败及每个边界的报告次数。
3. 接入 HTTP 和 Console，验收真实 HTML／JSON 协商、定制错误页、生产脱敏、认证和验证响应、协议头及退出码。功能通过后再补齐三语正文。
